#!/bin/bash

#  wrapper sccript for calling create_paula.sh
#  with zipped input and output (for WebService)

# ---------------------------------------------------------
# usage: ./create_paulaFromZipToZip.sh [OPTIONS] <fileIn.zip> <fileOut.zip> <type> 
# ---------------------------------------------------------
#

# assumption:
# common directory for WebService:
# /srv/homepages/d1/services/paula_webservice/wwwrun_tmp

# WebService has to guarantee that <fileIn.zip> and <fileOut.zip>
# are unique file names so that multiple users don't overwrite
# their data 
# -> after PAULA processing, WebService deletes input file 
# and ANNIS deletes output zip file

# NOTE: Webservice has to use the following parameters:
# input file <in.zip>: 
# /srv/homepages/d1/services/paula_webservice/wwwrun_tmp/<processID...in>
# -o /srv/homepages/d1/services/paula_webservice/wwwrun_tmp
#     for temporary files
# -f 
#     empty output dir 
# output file <out.zip>:
# /srv/homepages/d1/services/paula_webservice/wwwrun_tmp/<processID...out>


# for the time being, we don't support 
# -d DIR_DTD
# -t TAGSET_DECL
# -i STRUCT_ROOT
# -r
# -e EXM_TIER
# because these options must be set within ANNIS already
# -> we'll integrate that later... (so keep the options, don't delete them)

local=$(dirname $0)

USAGE="\\n USAGE: ./$(basename $0) [OPTIONS] DIR_IN DIR_OUT TYPE LOG\\n\\n\
  Wrapper script for create_paula.sh command\\n\\n\
 - FILE_IN.zip\\tinput zip file (*.zip)\\n\\n\
 - FILE_OUT.zip\\toutput zip file (*.zip)\\n\\n\
 - TYPE\\t\\tis one of: inline exmaralda mmax tiger urml\\n\\n\

 OPTIONS: \\n\
 uses the same options as create-paula.sh\\n\
 hence, call \"./create_paula.sh -h\" to see all options!!\\n\\n\
 NOTE: certain options are not yet supported, read info in script!!\\n\\n\
"

HELP=$USAGE

ARGS_wanted=3
ARGS_present=$#


#----------------------------------------
#  read in optional arguments
#----------------------------------------

#  Option arguments: don't process, just copy
my_optargs=""

while getopts "ho:fcd:t:i:re:" Option; do

    case $Option in
	h ) echo -e "$HELP"
	    exit;;

	#  need -o to make sure that WebService uses specific Dirs only
	#  redefine WORK and TMP!
	o ) let ARGS_present=$ARGS_present-2
	    # OPTARG=/srv/homepages/d1/services/paula_webservice/wwwrun_tmp
	    TMP=$OPTARG/$(mktemp)
	    WORK=$TMP/work
	    # for unpacking input zip file
	    ZIP_IN=$TMP/zipIn
	    # for PAULA standoff
	    PAULA_OUT=$TMP/paula
	    # use WORK as working directory
	    my_optargs="$my_optargs -$Option $WORK";;

	f ) let ARGS_present=$ARGS_present-1
	    my_optargs="$my_optargs -$Option";;
	    
	c ) let ARGS_present=$ARGS_present-1
	    my_optargs="$my_optargs -$Option";;

	d ) let ARGS_present=$ARGS_present-2
	    my_optargs="$my_optargs -$Option $OPTARG";;

	t ) let ARGS_present=$ARGS_present-2
	    my_optargs="$my_optargs -$Option $OPTARG";;

	i ) STRUCT_ROOT=$OPTARG
	    let ARGS_present=$ARGS_present-2;;

	r ) tiger_rev="yes"
	    let ARGS_present=$ARGS_present-1;;

	e ) let ARGS_present=$ARGS_present-2
	    my_optargs="$my_optargs -$Option $OPTARG";;

	? ) echo -e "unimplemented option chosen\\n$USAGE\\n"
	    exit 1
    esac
done

if [ "$ARGS_wanted" -ne "$ARGS_present" ]; then
    echo -en "\\n\\n\\n$HELP\\n\\n"
    exit 1
fi


if [ -z "$WORK" ]; then
    echo -e "\\nERROR: option -o must be specified!\\n"
    exit 1
fi


if [ ! -f "$local/create_paula.sh" ]; then
    echo -e "\\nERROR: script \"create_paula.sh\" not found\\n\
       (must be located in same directory as \"create_paulaFromDir.sh\")\\n"
    exit 1
fi

command_orig="$0 $@"

#----------------------------------------
#  read in obligatory arguments
#----------------------------------------

#  $1 now references the first non option item supplied on the command line
shift $(($OPTIND - 1))


FILE_IN=$1
if [ ! -f "$FILE_IN" ]; then
    echo -e "ERROR: file \"$FILE_IN\" not found"
    exit
fi

FILE_OUT=$2
TYPE=$3

command="mkdir -p $TMP/zipIn"
if ! $command; then 
    echo -e "ERROR occured during file conversion\\nCommand: $command\\n"
    exit 1
else
    # empty that directory
    rm -rf $TMP/zipIn/*
fi

command="cp $FILE_IN $TMP/in.zip"
if ! $command; then 
    echo -e "ERROR occured during file conversion\\nCommand: $command\\n"
    exit 1
fi

#----------------------------------------
#  now unzip file
#----------------------------------------

command="unzip -q -d $TMP/zipIn $TMP/in.zip"
if ! $command; then 
    echo -e "ERROR occured during file conversion\\nCommand: $command\\n"
    exit 1
fi


#----------------------------------------
#  now run standoff
#----------------------------------------


if [ $TYPE = "mmax" ]; then
    in="*.mmax"
else
    in="*"
fi

for file in $TMP/zipIn/$in; do
    command="$local/create_paula.sh $my_optargs $file $PAULA_OUT $TYPE"
done

if ! $command; then 
    echo -e "ERROR occured during file conversion\\nCommand: $command\\n"
    exit 1
fi


#----------------------------------------
#  finally zip output dir
#----------------------------------------

# otherwise zip *appends* to archives
rm -f $FILE_OUT

# zip -r file.zip dir
command="zip -j -q -r $FILE_OUT $PAULA_OUT"
if ! $command; then 
    echo -e "ERROR occured during file conversion\\nCommand: $command\\n"
    exit 1
fi

echo "Zip file saved to $FILE_OUT"

rm -rf $TMP
echo "intermediate files removed"

exit 0