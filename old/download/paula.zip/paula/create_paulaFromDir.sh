#!/bin/bash

#  wrapper sccript for calling create_paula.sh
#  NOTE: we assume that the input file's suffix is .xml or $TYPE!

# ---------------------------------------------------------
# usage: ./create_paulaFromDir.sh [OPTIONS] <dirIn> <dirOut> <type> <log>
# ---------------------------------------------------------
#


local=$(dirname $0)

USAGE="\\n USAGE: ./$(basename $0) [OPTIONS] DIR_IN DIR_OUT TYPE LOG\\n\\n\
 Wrapper script for create_paula.sh command\\n\\n\
 - DIR_IN\\tinput files will be searched in DIR_IN/*;\\n\
   \\t\\tNOTE: DIR_IN may be specified as \"path/*/\" but must be QUOTED!\\n\\n\
 - DIR_OUT\toutput files will be written to DIR_OUT/\$filename/*\\n\\n\
 - TYPE\\t\\tis one of: inline exmaralda mmax tiger urml\\n\\n\
 - LOG\\t\\tlog file \\n\

 OPTIONS: \\n\
 uses the same options as create_paula.sh\\n\
 hence, call \"./create_paula.sh -h\" to see all options!!\\n\
"

HELP=$USAGE

ARGS_wanted=4
ARGS_present=$#


#----------------------------------------
#  read in optional arguments
#----------------------------------------

#  Option arguments: don't process, just copy
my_optargs=""

while getopts "ho:fcd:t:i:re:m" Option; do

    case $Option in
	h ) echo -e "$HELP"
	    exit;;

	o ) let ARGS_present=$ARGS_present-2
	    my_optargs="$my_optargs -$Option $OPTARG";;

	f ) let ARGS_present=$ARGS_present-1
	    my_optargs="$my_optargs -$Option";;
	    
	c ) let ARGS_present=$ARGS_present-1
	    my_optargs="$my_optargs -$Option";;

	d ) let ARGS_present=$ARGS_present-2
	    my_optargs="$my_optargs -$Option $OPTARG";;

	t ) let ARGS_present=$ARGS_present-2
	    my_optargs="$my_optargs -$Option $OPTARG";;

	i ) STRUCT_ROOT=$OPTARG
	    let ARGS_present=$ARGS_present-2;;

	r ) tiger_rev="yes"
	    let ARGS_present=$ARGS_present-1;;

	e ) let ARGS_present=$ARGS_present-2
	    my_optargs="$my_optargs -$Option $OPTARG";;

	m ) let ARGS_present=$ARGS_present-1
	    my_optargs="$my_optargs -$Option";;

	? ) echo -e "unimplemented option chosen\\n$USAGE\\n"
	    exit 1
    esac
done

if [ "$ARGS_wanted" -ne "$ARGS_present" ]; then
    echo -en "\\n\\n\\n$HELP\\n\\n"
    exit 1
fi


if [ ! -f "$local/create_paula.sh" ]; then
    echo -e "\\nERROR: script \"create_paula.sh\" not found\\n\
       (must be located in same directory as \"create_paulaFromDir.sh\")\\n"
    exit 1
fi

command_orig="$0 $@"

#----------------------------------------
#  read in obligatory arguments
#----------------------------------------

#  $1 now references the first non option item supplied on the command line
shift $(($OPTIND - 1))


DIR_IN=$1
#if [ ! -d "$DIR_IN" ]; then
#    echo -e "ERROR: directory \"$DIR_IN\" not found"
#    exit
#fi

DIR_OUT=$2
TYPE=$3
LOG=$4

function answer_ade () {
    if [ "$answer" = "e" ]; then
	echo -e "\\nExiting...\\n";
	exit 1
    else 
	if [ "$answer" = "d" ]; then
	    rm -f $LOG
	    if [ $? -ne "0" ]; then 
		echo "ERROR: could not remove \"$LOG\""
		exit
	    fi
	fi
    fi
}

if [ -f $LOG ]; then
    #  prompt user before deleting files
    echo -en "WARNING: log file \"$LOG\" already exists!\\n\
Append or delete file, or exit [a/d/e]? > "
    read answer
    answer_ade

    # catch wrong answers
    while [ "$answer" != "a" ] && 
    [ "$answer" != "d" ] &&  
    [ "$answer" != "e" ]; do
      echo -n "Please type \"a\", \"d\", or \"e\"! Append or delete file, or exit [a/d/e]? > "
      read answer
      answer_ade
    done
else
    # LOG is new -> create directory, if necessary
    LOGDIR=$(dirname $LOG)
    if [ ! -d $LOGDIR ]; then
	mkdir -p $LOGDIR
    fi
fi



#----------------------------------------
#  temporary LOG files
#----------------------------------------

LOG_OK=$(mktemp)
LOG_ERROR=$(mktemp)
LOG_COMMAND=$(mktemp)


#----------------------------------------
#  now run standoff
#----------------------------------------

#  record start time
time_start=$(date +%X )


if [ $TYPE = "mmax" ]; then
    in="*.mmax"
else
    in="*"
fi
  
count=0
for file in $DIR_IN/$in; do
    NAME=$( basename "$file" | \
	sed -re s/.xml$// | \
	sed -re s/.$TYPE$// )

    command="$local/create_paula.sh $my_optargs $file $DIR_OUT/$NAME $TYPE"

    if ! $command; then 
	echo "$file" >> $LOG_ERROR
	echo "$command" >> $LOG_COMMAND
    else 
	echo "$file" >> $LOG_OK
    fi
    let count=$count+1;
done

time_end=$(date +%X )

files_ok=$(wc -w $LOG_OK | gawk '{print $1}')
files_error=$(wc -w $LOG_ERROR | gawk '{print $1}')

#  now write LOG file

echo "" >> $LOG
echo "----------------------------------------" >> $LOG
echo "CONVERSION INFO from script \"$(basename $0)\"" >> $LOG
echo "date:    $(date +%b\ %d\ %Y)" >> $LOG
echo "user:    $(whoami)" >> $LOG
echo "#files:  $count files processed (ok: $files_ok, errors: $files_error)" >> $LOG
echo "start:   $time_start, end: $time_end" >> $LOG
echo "command: $command_orig" >> $LOG
echo "----------------------------------------" >> $LOG
echo "" >> $LOG


if [ -s "$LOG_ERROR" ]; then
    echo "----------------------------------------" >> $LOG
    echo "ERRORS occured with the following files" >> $LOG
    echo "(corresponding commands: see end of file)" >> $LOG
    echo "----------------------------------------" >> $LOG
    echo "" >> $LOG
    cat $LOG_ERROR >> $LOG
fi

if [ -s "$LOG_OK" ]; then
    echo "----------------------------------------" >> $LOG
    echo "No problems with the following files" >> $LOG
    echo "----------------------------------------" >> $LOG
    echo "" >> $LOG
    cat $LOG_OK >> $LOG
fi

if [ -s "$LOG_COMMAND" ]; then
    echo "----------------------------------------" >> $LOG
    echo "Commands that invoked errors">> $LOG
    echo "----------------------------------------" >> $LOG
    echo "" >> $LOG
    cat $LOG_COMMAND >> $LOG
    echo "" >> $LOG
fi

echo "" >> $LOG
if [ $? -eq "0" ]; then
    echo ""
    echo "LOG written to \"$LOG\""
    echo ""
fi

rm -f $LOG_OK $LOG_ERROR $LOG_COMMAND

exit 0

