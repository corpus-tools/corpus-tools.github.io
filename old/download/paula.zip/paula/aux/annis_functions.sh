#!/bin/bash

PROGNAME=$(basename $0)

#########################################################
function error_exit () {
#########################################################
#  Function for exit due to fatal program error
#+ Accepts 2 argument:
#+ line number ($LINENO: current line number)
#+ string containing descriptive error message
#+ (copied and adapted from: http://linuxcommand.org/)

    if [ ! -z "$LOG" -a -z "$LOG_ERR" ]; then
        cd $LOG
        if grep '.' $LOG_ERR; then
            echo "--------------------------"
            echo "WARNING"
            echo "there were error messages by script $PROGNAME:"
            cat $LOG_ERR
            echo "--------------------------"
        fi
    fi

    echo
    echo -e "${PROGNAME}: $1 \\n ERROR: ${2:-"Unknown Error"}" 1>&2
    echo

    if [ "$clean" = "yes" ]; then
	rm -rf $WORK
	echo "$WORK removed"
    fi

    exit 1
}


#########################################################
function log_comm () {
#########################################################
#  write commands to log file
#+ 1st argument: "environment" (e.g. 'xdoc')
#+ 2nd argument: command

    echo "---------------" >> $LOG_COMM
    echo "$1" >> $LOG_COMM
    echo "---------------" >> $LOG_COMM
    echo -e "$2" >> $LOG_COMM
    echo "" >> $LOG_COMM
}


#########################################################
function log_out () {
#########################################################
#  write selected output to log file
#+ 1st argument: kind of header
#+ 2nd argument: name of output file
#+ 3rd argument: whether to display log in mozilla or not

    echo "----------------------------" >> $LOG_OUT
    echo "$1" >> $LOG_OUT
    echo "$2" >> $LOG_OUT
    echo "----------------------------" >> $LOG_OUT
    if [ -f $2 ]; then
	cat "$2" >> $LOG_OUT
    fi
    echo "" >> $LOG_OUT


    if [ $3 -eq "0" ]; then
	$MOZILLA -remote "openURL(file://$2,new-tab)" &
    fi
}
#########################################################
function check_value () {
#########################################################
#  Takes option flag, option value and array with predefined values
#+ and checks if value is a member of that array

    flag=$1
    shift

    value=$1
    shift

    # read in array
    array=( `echo "$@"` )

    array_count=${#array[@]}
    my_exit=1
    i=0

    while [ "$i" -lt "$array_count" -a  $my_exit -eq "1" ]; do
        echo ${array[$i]} | grep -qx $value -
        # check for exit status of grep command
        my_exit=$?
        let "i=$i+1"
    done

    #  check for exit status of last grep command
    if [ "$my_exit" -eq "1" ]; then
        error_exit $LINENO "Wrong option \"$flag $value\"\\n$USAGE"
    fi

}

#########################################################
function absolute_file () {
#########################################################
#  transforms relative paths into absolute ones (in file names)

echo "$(cd -P $(dirname $1) && pwd)/$(basename $1)"
if [ $? -ne 0 ]; then
    echo "ERROR occured whil transforming \"$1\""
fi
}


#########################################################
function absolute_dir () {
#########################################################
#  transforms relative paths into absolute ones (in paths)

mkdir -p $1
echo "$(cd -P $1 && pwd)"
if [ $? -ne 0 ]; then
    echo "ERROR occured whil transforming \"$1\""
fi
}

##############################################################
# not used currently

function usage {

	# Display usage message on standard error
	echo "Usage: $@" 1>&2
}



#The $TEMP_DIR variable contains either /tmp or ~/tmp depending on the availability of the directory. It is common practice to embed the name of the program into the file name. We have done that with the string "printfile". Next, we use the $$ shell variable to embed the process id (pid) of the program. This further helps identify what process is responsible for the file. 

TEMP_FILE=$TEMP_DIR/printfile.$$.$RANDOM
