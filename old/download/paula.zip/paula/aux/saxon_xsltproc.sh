#!/bin/sh

# adjust path of variable
#export JAVA=/usr/lib/java

export JAVA=/usr/lib/java/bin/java
export CLASSPATH=/srv/projects/d1/lib/saxon/saxon8.jar
export SAXONPATH=/srv/projects/d1/lib/saxon

$JAVA net.sf.saxon.Transform -o $1 $2 $3 $4 $5 $6 $7 $8 $9


