#!/bin/bash

#set -xv   # xtrace und verbose aktivieren
#set -o verbose sh -v 

# ---------------------------------------------------------
# usage: ./create_paula.sh [OPTIONS] <fileIn> <dirOut> <type>
# ---------------------------------------------------------
#
# ---------------------------------------------------------
# takes XML annotations and produces PAULA format
# ---------------------------------------------------------

#  TODOs
#  . replace 'type' attribute by 'layer' attribute
#    and add new 'type' feature:
#    - for <structList>: type = graph/tree
#    - for <markList>:   type = char_based/mark_based
#    - for <featList>:   type = free_text/tags_withTagset/
#                               tags_withoutTagset/pointer
#  . with external tagsets: modify tag values like '1' or '%L' 
#    -> these are not valid XML IDs!!
#
#  . NOTE: if you plan to introduce multifeats for other types than mmax
#    (which is already done), you must check ALL scripts for <featList>
#    and add <multiFeatList> as another option. Otherwise, get rid of the 
#    extra tag <multiFeatList> and call it <featList>, then everything
#    should be alright (but less transparent, for further processing)


#  change log:
#  19 Sep 07:
#  . no empty annotation files for MMAX (cause problems for UK inline scripts)
#  3 Sep 07:
#  . added type=palinka; special feature: 
#  . relation (= empty first child) is copied to mother element 
#    NOTE: Palinka allows more than one empty child, but we 
#    only modify the very first! Otherwise: we would have to think about
#    duplicated attribute names etc...
#    NOTE: relation attributes are renamed to 'Rel_...' to avoid feature clashes
#  . after that modification: same treatment as inline
#
#  3 July 07:
#  . added hashes in front of "simple" links like 'const_25'
#    (it's now '#const_25')
#
#  18 May 07:
#    . multi feats for mmax data (option -m; old option -m becomes -v = visual)
#
#  30 Jan 07:
#    . new file naming conventions: <sourceType>.<name>.<ID>.<annoType>.xml
#- the fields are separated by a dot, hence, none of <sourceType>, <name>,
#  etc. may contain a dot
#  sourceType: supplied by this script (one of "mmax tiger exmaralda urml
#              inline")
#  name:       some arbitrary name like "syntax" or "alternativeAnnotation"
#  ID:         ID must be identical for all files that are to be merged
#  annoType:   e.g. "tok" or "tok_lemma" etc.
#
#  2 Jan 07:
#    . new way of creating annoSet file (now done by looking at xml:base feature)
#  Dec 06:
#    . added validity check for input formats
#    . default for generic inline: root node (flag -i now optional)
#  Oct 06:
#    . added type=inline
#
#  Aug/Sep 06: major revisions in multiple places
#    . renamed "sfb632" by "paula" (e.g. paula_id, root tag, DTDs, ...)
#    . new parameters (e.g. output directory for standoff: now obligatory)
#    . added a lot of exit status checks
#    . header now doesn't contain type attribute any more, except for text files
#      (type was redundant information; use layer attribute of markList, featList,
#       structList from now on)
#    . modified tagsets type (in annoSet and tagset XML files):
#      now also contains name of tagset layer, e.g.: type_pos and value_pos
#    . <feat> tags may only point to one ID from now on, i.e. Exmaralda annotations
#      now all get extra markable layers
#    . empty tiers allowed from now on, since empty tiers may mean: "no 
#      element of type 'tier' found" (vs. "type 'tier' not annotated at all")
#    . put some functionality in extra perl scripts, to make shell script simpler
#    . now using more uniform stylesheet parameters (e.g. 'paula_text')
#    . modified analysis of mmax anaphor_antecedent: doesn't use 'target' attribute
#      any more but simple 'value' attribute
#  19 June 06:
#    . added anno_feat.xml file to anno.xml file 
#      (so that anno.xml now lists all standoff xml files)
#    . added secmark handling to "target" attributes of anaphor_antecedent relations
#      (mmax feature)
#  2 June 06:
#    . added guessing for tier with primary data (Exmaralda)
#  11 Apr 06:
#    . modified anno_feat files: 
#      all ordinary features now point to <rel> rather than <struct>
#      (meta info and tagsets still point to <struct>)
#  3 Mar 06/23 Mar 06:
#    . added another check for validity: check for matching pairs of parenthesis
#  2 Mar 06:
#    . modified quick validity check slightly (to recognize more errors)
#    . if cat=ahd in Exmaralda data: then guess TIE1 as primary layer
#  27 Feb 06:
#    . fixed ID values in type hierarchy: $. is now DOLLAR_PERIOD etc.
#    . added quick check for valid attributes (i.e. script exits if ""
#      or _) is found) -> NOTE: this occurs in Exmaralda if some annotations
#      refer to empty field on primary data tier!!
#  20 Feb 06:
#    . modified <header type> values for external tagsets:
#      type=typeHierarchy (for structs) and type=typeValue (for feats)
#  7 Feb 06:
#    . fixed bug in mmax tok_sent file (didn't have header tag)
#+     NOTE: xmllint --valid does not check DTD parts
#+     that are included by %entity references!!
#  6 Feb 06:
#    . renamed scripts/ directory into aux/ (and $SCRIPTS into $AUX)
#  2 Feb 06:
#    . put all standoff scripts under svn version control
#    . bash/perl scripts: now called by 'bash ...' etc.
#      i.e. don't need to be executable any more
#    . modified format of tagset declarations slightly
#  30 Jan 06:
#    . modifications of command line options
#+     -o: now refers to output directory of *standoff* files only
#+     -c: keeps copy of all intermediate representations (= old -o)
#+   . default is now: all intermediate representations are removed
#+     after processing so that /tmp/ is not messed up to much...
#+   . NOTE: either -c or -o should be set otherwise all output is removed
#  18 Jan 06: 
#    . renamed flag '-i' (ignore) by '-f' (force)
#+     since '-i' normally means 'interactive'
#    . renamed parameter 'type' by 'TYPE' to prevent accidental reusage
#    . output file names now contain 'TYPE' (tiger/mmax/...)
#+     to ease collecting all annotations to one text
#+     so that we can be sure that all annotation files are called differently
#+     (otherwise the script collecting all annotations to one text
#+     would overwrite files that are named identically)
#  17 Jan 06: 
#    . removed specification: encoding="UTF-8"
#+     from all XSLT stylesheets that read in UTF-8 anyways
#+     otherwise non-ascii characters get corrupted for some reason...
#+     (e.g. without encoding="UTF-8", 'ue' now becomes: &#xFC;
#+           with encoding="UTF-8", 'ue' would become: ÃÂ¼)
#+     NOTE: it seems to make a difference whether Umlaut becomes part of  
#+     a comment or document content -> comments are still corrupted...
#    . new flag '-c DIR' for specifying an additional (optional) 
#+     output directory for standoff files
#  10 Jan 06: 
#    . output directory: *_standoff (instead of *_analyses)


# ASSUMPTIONS:
#  . input files are called *.xml or *.$TYPE (e.g. *.tiger)
#  . each input file corresponds to one document in ANNIS
#+   otherwise: split your input file beforehand (e.g. URML, TIGER)

#  we use some special, pre-defined attributes, which shouldn't be used:
#+ paula_id, type, name, value
#+ _char_numbers, _char_start, _char_end
#+ _paula_text, _paula_word, _paula_const, _paula_rel
#+ attributes called "_*" don't appear in the final files

#  TIGER
#  secondary edges are reversed (default); otherwise use option -r

#  URML 
#+ some hard-coded assumptions:
#+ all element names: hard-coded
#+ <segment>s are the only RST-relevant markables
#+ <sign>s are the only relevant daughters of <segment>
#+ ...

#  MMAX 
#+ we read in the MMAX file specifying the "mmax_project"
#+ and the <words> element in that file determines the actual input file
#+ naming conventions: 
#+ . each "annotation project" is marked by the same prefix (in file name)
#+ . we assume that 'markable_' refers to 'primmark_' and
#+   'secmark:markable' to 'secmark' etc.
#+ . all annotations are stored in files _*_level.xml
#+   and the annotation type is indicated by _<*>_level
#+   (actually this info is contained in file 'common_paths.xml'
#+   i.e. at some point, read out info from this file)


# TODOs:

#  - don't know how to insert namespace elements like xmlns:xlink
#+ into xml documents -> currently hack: insert xmlns_xlink
#+ and then replace underscore by perl script ...
#+ (more precisely: this works:
#+ <xsl:attribute name="xlink:href" namespace="{$xmlns_xlink}">
#+ however, then each single element gets the huge xlink URL
#+ attached to it, which makes the file hard to read)
#
#  - Exmaralda: "interpret" hierarchical annotations
#+ (encoded via special tier names like CS_1 and CS_2
#+ meaning that CS_1 is supposed to be dominated by CS_2)
#
#  - TIGER/URML/MMAX: read in <header> info and create tagset from it
#
#  - URML 
#+ we delete empty <segment>s (= with no or empty <sign> children)


#########################################################
#  Structure of the program
#########################################################

# Some paths etc.
# Standard Check for Script Argument(s)
# Working directories
# DTDs and Tagsets

# START OF PROCESSING
# 1. Make sure input file is in UTF-8 
# 2. Tool-specific preprocessing
# 3. Read in tagset information
# 4. Add character information
# 5. Standoff files: Text
# 6. Standoff files: Tokens (referring to text) 
# 7. Standoff files: Markables and their annotations
# 8. Standoff files: Tree/Graph annotations (syntax, RST,...)
# 9. Standoff files: Generic inline
# 10. Standoff files: Meta information
# 11. Standoff files: Create meta-info  and anno-set files
# 12. Standoff files: Replace certain attributes/values
# 13. Standoff files: Check for validity


#########################################################
#  Some paths etc.
#########################################################

echo ""

local=$(echo "$(cd -P $(dirname $0) && pwd)")
AUX=$local/aux

# directory for tool DTDs (tiger, mmax, ...)
DTD=$local/dtd

#  source general functions (located in subdirectory aux/)
. $AUX/annis_functions.sh
if [ "$?" -ne "0" ]; then
    echo "FATAL ERROR: could not source functions; EXITING"
    exit 1
fi


#----------------------------------------
# Tools
#----------------------------------------

BASH=$(which bash)
MOZILLA=$(which mozilla)
PERL=$(which perl)
PYTHON=$(which python)
XSLTPROC=$(which xsltproc)
XMLLINT=$(which xmllint)
JAVA=$(which java)

#  saxon XSLT processor (called with customized arguments)
SAXON_XSLTPROC=$AUX/saxon_xsltproc.sh

# for xalan
export CLASSPATH="/usr/share/java/xalan-j2.jar"

#########################################################
#  Standard Check for Script Argument(s)
#########################################################

TYPES=( inline exmaralda mmax palinka tiger urml )

HELP="\\n USAGE: ./$(basename $0) [OPTIONS] FILE_IN DIR_OUT TYPE\\n\
 HELP:  ./$(basename $0) -h"

USAGE="\\n USAGE: ./$(basename $0) [OPTIONS] FILE_IN DIR_OUT TYPE\\n\\n\
 FILE_IN is the input file (*.xml)\\n\
 DIR_OUT is the output directory for standoff files\\n\
 TYPE is one of: ${TYPES[@]}\\n\

 OPTIONS:\\n\
 -h\\t\thelp (this page)\\n\\n\

 -f\\t\tforce: empty output directory without prompt\\n\

 -o WORK \\tdirectory to save otherwise temporary files\\n\
\t\tNOTES: - all previous files and subdirectories in WORK will be deleted!\\n\
\t\t       - DIR_OUT must not be embedded in WORK!\\n\
 -c\\t\tclean: remove working directory WORK after crash\\n\

 -d DTD_PAULA\\twhere DTD_PAULA is the directory with Paula DTDs\\n\
\t\t(default: in subdirectory dtd/paula)\\n\

 -t TAGSET_DECL\\tTAGSET_DECL is a file hat lists all annotation layers\\n\
\t\tthat come with a tagset declaration\\n\
\t\tformat of TAGSET_DECL: each single line specifies: \\n\
\t\t- the name of the feature/annotation layer (e.g. pos),\\n\
\t\t  followed by @@ (without intervening spaces!)\\n\
\t\t- plus the (path to the) file with the tagset <struct>\\n\
\t\t  declarations, followed by @@ (without intervening spaces!)\\n\
\t\t- plus the (path to the) file with the tagset <feat>\\n\
\t\t  declarations\\n\

 -m \\t\\tdo NOT use multi-feat tags (tags that annotate\\n\
\\t\\tmultiple features to one markable)\\n\

 -i STRUCT_ROOT\\twhere STRUCT_ROOT is the root node of the relevant XML subtree\\n\
\t\t(optional with type=\"inline\")\\n\

 -r\\t\\treverse: DO NOT reverse secondary edges (TIGER only)\\n\
\t\tDEFAULT: direction of pointers are reversed\\n\

 -e EXM_TIER \\twhere EXM_TIER is one of TIEn, n>=0 (default: TIE0)\\n\
\t\twhich specifies the tier containing the primary data\\n\

 -v\\t\tvisual: display intermediate files in mozilla\\n\t\t(WARNING: slow!!)\\n"


ARGS_wanted=3
ARGS_present=$#


#----------------------------------------
#  read in optional arguments
#----------------------------------------

#  character+colon: option requires argument (e.g. '-e')

while getopts "ho:fcd:t:mi:re:v" Option; do

    case $Option in
	h ) echo -e "$USAGE"
	    exit;;

	o ) WORK=$OPTARG
	    keep_files="yes"
	    let ARGS_present=$ARGS_present-2;;

	f ) force="yes"
	    let ARGS_present=$ARGS_present-1;;

	c ) clean="yes"
	    let ARGS_present=$ARGS_present-1;;

	d ) DTD_PAULA=$OPTARG
	    let ARGS_present=$ARGS_present-2;;

	t ) tagsetDecl=$OPTARG
	    let ARGS_present=$ARGS_present-2;;

	m ) multFeat="no"
	    let ARGS_present=$ARGS_present-1;;

	i ) STRUCT_ROOT=$OPTARG
	    let ARGS_present=$ARGS_present-2;;

	r ) tiger_rev="no"
	    let ARGS_present=$ARGS_present-1;;

	e ) exm_tier=$OPTARG
	    let ARGS_present=$ARGS_present-2;;

	v ) visual=0
	    let ARGS_present=$ARGS_present-1;;

	? ) echo -e "unimplemented option chosen\\n$HELP"
    esac
done

if [ "$ARGS_wanted" -ne "$ARGS_present" ]; then
    echo -e "Usage: \\n$HELP\\n"
    exit 1;
fi


echo "-----------------------------------------"
echo "command: $0 $@"
echo "-----------------------------------------"


#----------------------------------------
#  read in obligatory arguments
#----------------------------------------

#  $1 now references the first non option item supplied on the command line
shift $(($OPTIND - 1))



#----------------------------------------
#  3rd argument: TYPE
#----------------------------------------

#+ check whether $3 is part of array @TYPES
#  (need $TYPE for ID extraction from file name)

TYPE=$3
check_value "TYPE" $TYPE ${TYPES[@]}


#----------------------------------------
#  1st argument: input file
#----------------------------------------

file_in=$1
file_orig=$file_in

if [ ! -f "$file_in" ]; then
    error_exit $LINENO "input file \"$file_in\" not found"
fi

#  determine $name based on input file name
#+ delete spaces and commas in file names
#+ (commas are problematic for output directory names)
#+ and remove extensions like .xml
if $(echo "$file_in" | grep -q " "); then
    file_in=$(echo "$file_in" | sed -e 's/ /_/g' | sed -e 's/,//g')
fi

NAME=$( basename "$file_in" | \
sed -re s/.xml$// | \
sed -re s/.$TYPE$// )

# MMAX special: need input path (for further standoff files)
file_abs="$(absolute_file $file_in)"
path_abs="$(dirname $file_abs)"


#----------------------------------------
# 2nd argument: DIR_OUT
#----------------------------------------

#  output directory for standoff files

DIR_OUT=$2

function answer_yn () {
    if [ "$answer" = "n" ]; then
	echo -e "\\nExiting...\\n";
	exit 1
    else 
	if [ "$answer" = "y" ]; then
	    rm -rf  $DIR_OUT/*
	fi
    fi
}


#  first test whether DIR_OUT already exists
if [ -d $DIR_OUT ]; then

    #  if so, test next whether we have writing permissions
    touch $DIR_OUT/tmp_test
    if [ "$?" -ne "0" ]; then
	error_exit $LINENO "no writing permissions in DIR_OUT \"$DIR_OUT/\"";
    else
	rm $DIR_OUT/tmp_test
    fi

    #  remove files without asking
    if [ -n "$force"  ]; then
	rm -f $DIR_OUT/* 2> /dev/null

    #  check whether there are files in DIR_OUT
    else
	if [ -n "$(ls -A $DIR_OUT)" ]; then
	    #  prompt user before deleting files
	    echo -en "WARNING: output directory \"$DIR_OUT/\" is not empty!\\n\
Delete files [y/n]? > "
	    read answer
	    answer_yn

	    # catch wrong answers
	    while [ "$answer" != "n" -a "$answer" != "y" ]; do
		echo -n "Please type \"y\" or \"n\"! Delete files [y/n]? > "
		read answer
		answer_yn
	    done
	fi
    fi

#  directory does not yet exist
else
    #  create directory
    mkdir -p $DIR_OUT
    if [ "$?" -ne "0" ]; then
	error_exit $LINENO "could not create DIR_OUT \"$DIR_OUT\"";
    fi
fi


#----------------------------------------
#  check values and assign default values to optional arguments
#----------------------------------------

#  note: first process obligatory arguments
#+ since here, we need $NAME and check for $TYPE

if [ -z "$WORK" ]; then
    # note: use '$(mktemp)' since otherwise, parallel processing
    # e.g. of PCC annotations may result in identical $WORK directory!
    WORK=$(mktemp -d)
    #echo ">>> assuming default value: WORK = $WORK"
fi

if [ -z "$DTD_PAULA" ]; then
    DTD_PAULA="$DTD/paula"
fi

if [ -z "$visual" ]; then
    visual=1
fi

#  per default: assume that there are no meta infos
meta_exist="no"


#  tagset declarations
if [ -n "$tagsetDecl" ]; then
    tagset_exist="yes"
    if [ ! -f "$tagsetDecl" ]; then
	error_exit $LINENO "file not found: \"$tagsetDecl\""
    fi
    TAGSET=$(dirname $(absolute_file $tagsetDecl))
fi


#  multi feats: default = yes
if [ -n "$multFeat" ]; then
    true
else
    # assign default value: yes
    multFeat="yes"
fi


#  tiger: reverse edges
if [ -n "$tiger_rev" ]; then
    if [ "$TYPE" != "tiger" ]; then
	error_exit $LINENO "option '-r' only makes sense with TIGER data\\n$HELP"
    fi
else
    # assign default value: yes
    tiger_rev="yes"
fi

#  exmaralda tier for primary data
if [ -n "$exm_tier" ]; then
    if [ "$TYPE" = "exmaralda" ]; then
        #  check whether option arguments are part of array @TYPES
        echo "$exm_tier" | grep -Eq '^TIE[0-9]+$'
	if [ "$?" -eq "0" ]; then 
	    true
	else
	    error_exit $LINENO "not a valid tier: \"$exm_tier\""  
	fi
    else
	error_exit $LINENO "option '-e' only makes sense with Exmaralda data\\n$HELP"
    fi
fi

#########################################################
#  Working directories
#########################################################

#  create directories (silently)
#+ transform directory path into absolute path

mkdir -p $WORK
#  note: for this to work, the directory must exist already!
WORK=$(cd -P $WORK && pwd)

IN=$WORK/in
PREP=$WORK/prep
SYNTAX=$WORK/syntax_prep
MISC=$WORK/misc
STOFF=$WORK/standoff_tmp
STOFF_FINAL=$WORK/standoff_final

#  need these directories so that loop over multiple files is easier
EXM=$WORK/exm
MMAX=$WORK/mmax

LOG=$WORK/log
LOG_ERR=$LOG/errors.log
LOG_COMM=$LOG/commands.log
LOG_OUT=$LOG/analyses.log
LOG_MSG=$LOG/messages.log


#----------------------------------------
#  create/empty working directories
#----------------------------------------

#  directory for temporary files: delete without asking
if [ -d "$WORK" ]; then
    rm -rf $WORK
else
    #  this should never happen...
    error_exit $LINENO "WORK \"$WORK\" is not a directory!"
fi

#  -p: silent + create parent directories if necessary
mkdir -p $IN
mkdir -p $PREP
mkdir -p $SYNTAX
mkdir -p $MISC
mkdir -p $STOFF
mkdir -p $STOFF_FINAL

mkdir -p $EXM
mkdir -p $MMAX

mkdir -p $LOG

if [ -n "$keep_files" ]; then
    echo -e "\\n>>> log files:\\n\
  $LOG_COMM\\n\
  $LOG_ERR\\n\
  $LOG_OUT\\n\
  $LOG_MSG\\n"
fi


#########################################################
#  DTDs and Tagsets
#########################################################

#----------------------------------------
#  copy DTDs to standoff directory for validation check
#----------------------------------------

if [ -z "$(ls -A $DTD_PAULA)" ]; then
    error_exit $LINENO "no DTDs found in \"$DTD_PAULA/\""
fi

log_comm pipeline:dtds "cp $DTD_PAULA/paula*.dtd $STOFF_FINAL"
cp $DTD_PAULA/paula*.dtd $STOFF_FINAL


#----------------------------------------
#  copy tagset declarations to standoff directory
#----------------------------------------

if [ "$tagset_exist" = "yes" ]; then

    while read layerTagset; do  # input: < $tagsetDecl

	#  first check for correct input format
	echo "$layerTagset" | grep -qE '^[^@]+@@[^@]+@@[^@]+$'
	if [ "$?" -ne "0" ]; then 
	    error_exit $LINENO "file \"$tagsetDecl\" not in correct format"
	fi

	tagsetStruct=$(echo "$layerTagset" | perl -pe 's/^(.+?)@@(.+?)@@(.+)$/$2/')
	tagsetValue=$(echo "$layerTagset" | perl -pe 's/^(.+?)@@(.+?)@@(.+)$/$3/')

	tagsetStruct=$(absolute_file $TAGSET/$tagsetStruct)
	tagsetValue=$(absolute_file $TAGSET/$tagsetValue)

	if [ ! -f "$tagsetStruct" ]; then
	    error_exit $LINENO "file not found: \"$tagsetStruct\"\\n"
	fi
	if [ ! -f "$tagsetValue" ]; then
	    error_exit $LINENO "file not found: \"$tagsetValue\"\\n"
	fi

	#  superficial checks for correct format
	grep -q '<struct' $tagsetStruct
	if [ "$?" -ne "0" ]; then 
	    error_exit $LINENO "file \"$tagsetStruct\" not in correct format"
	fi
	grep -q '<feat' $tagsetValue
	if [ "$?" -ne "0" ]; then 
	    error_exit $LINENO "file \"$tagsetValue\" not in correct format"
	fi

	#  note: for simplicity, we copy tagsets to output directory 
	#+ even if no tagset-relevant feature is annotated at all
	log_comm pipeline:tagsets "cp $tagsetStruct $STOFF"
	log_comm pipeline:tagsets "cp $tagsetValue $STOFF"
	cp $tagsetStruct $STOFF_FINAL
	cp $tagsetValue $STOFF_FINAL

    done < $tagsetDecl

fi

#----------------------------------------
#  rename + copy source file
#----------------------------------------

if [ "$TYPE" != "mmax" ]; then
    #  copy input file to IN directory 
    #+ (possibly new file name, with spaces removed)
    log_comm  pipeline:input "cp \"$file_orig\" $IN/$NAME.xml"
    cp "$file_orig" $IN/$NAME.xml

else
    # copy entire mmax annotation project
    log_comm  pipeline:input "cp $path_abs/${NAME}_words.xml $IN/"
    log_comm  pipeline:input "cp $path_abs/${NAME}_*_level.xml $IN/"
    cp $path_abs/${NAME}_words.xml $IN/
    cp $path_abs/${NAME}_*_level.xml $IN/
fi

log_out "Original source text" "$IN/$NAME.xml" $visual


#----------------------------------------
#  SPECIAL: Palinka
#----------------------------------------

# treat Palinka like ordinary inline format, to one exception:
# transform element <REL SRC="..."> by integrating it into dominating node
# afterwards set TYPE to inline
# NOTE: Palinka allows more than one empty child, but we only modify 
#       the very first! Otherwise: we would have to think about
#       duplicated attribute names etc...
# NOTE: relation attributes are renamed to 'Rel_...' to avoid feature clashes

if [ "$TYPE" = "palinka" ]; then
    in=$IN/$NAME.xml
    out=$IN/$NAME.xml.new

    prog="$XSLTPROC --novalid"
    styl=$AUX/palinka_transformRel.xsl
    command="$prog -o $out $styl $in"
    
    log_comm pipeline:preprocessing "$command"
    if $command; then
	true
    else
	error_exit $LINENO "Error(s) while preprocessing\\nCommand: \"$command\""
    fi
    
    # now set type to inline
    TYPE=inline 
fi


#----------------------------------------
#  try to figure out which Exmaralda tier contains primary data
#----------------------------------------
#+ 2 types of check: 
#+ (i) B4 data: <tier id="TIE1" category="ahd">
#+ (ii) others: <tier category="[Ww]ord*">

if [ "$TYPE" = "exmaralda" -a -z "$exm_tier" ]; then
    prog="$AUX/exmaralda_guessPrimTier.perl"
    in=$IN/$NAME.xml
    out=$MISC/exmaralda_guessPrimTier.txt
    log=$LOG_MSG
    command="$PERL $prog $in $out"

    log_comm pipeline:input "$command"
    if $command; then
	exm_tier=$(cat $out)
    else
	error_exit $LINENO "Error(s) during guessing of Exmaralda tier\\nCommand: \"$command\""
    fi
fi


#########################################################
# START OF PROCESSING
#########################################################

#########################################################
# 1. Make sure input file is in UTF-8 
#########################################################

#  NOTE: last time we look at files in $IN
#  NOTE: need loops for MMAX files!!
#  NOTE: use --format with xmllint to normalize input layout


for file in $IN/${NAME}*.xml; do

    if [ "$TYPE" = "mmax" ]; then
	# if it's mmax:
        #+ namespace attribute "www.eml.org/NameSpaces/secmark" not valid 
        #+ -> delete completely, otherwise xmllint won't work!
	prog="$AUX/mmax_renaming.perl"
	
	command="$PERL $prog $file $file.tmp"
	log_comm pipeline:utf8 "$command"

	if $command; then
	    true
	else 
	    error_exit $LINENO "Error(s) with mmax renaming\\nCommand: \"$command\""
	fi

	command="mv $file.tmp $file"
	log_comm pipeline:utf8 "$command"

	if $command; then
	    true
	else 
	    error_exit $LINENO "Error(s) with mmax renaming\\nCommand: \"$command\""
	fi
    fi

    in=$file
    prog="$XMLLINT --format --encode utf-8"
    out="$PREP/$(basename $file).utf8"

    command="$prog -o $out $in"
    log_comm pipeline:utf8 "$command"
    
    if $command; then
	echo ". utf8 version: $(basename $out)"
    else 
	error_exit $LINENO "Error(s) with utf8 conversion\\nCommand: \"$command\""
    fi

done
    

#  check input for validity (using tool-specific DTDs)

#  first copy dtds/schemas to PREP -- facilitates validation
if [ $TYPE != "inline" ]; then
    command="cp $DTD/$TYPE/* $PREP"
    log_comm pipeline:utf8 "$command"
    if $command; then
	true
    else 
	error_exit $LINENO "Error copying dtd\\nCommand: \"$command\""
    fi
fi

# now validate
for file in $PREP/*.utf8; do

    validCall="--valid"

    if [ "$TYPE" = "exmaralda" ]; then
	validCall="--dtdvalid $DTD/exmaralda/basic-transcription.dtd"
    fi
    if [ "$TYPE" = "tiger" ]; then
	validCall="--schema $DTD/tiger/TigerXML.xsd"
    fi
    if [ "$TYPE" = "urml" ]; then
	# for some reason, URML files don't find their DTD
	# (on helios)
	validCall="--dtdvalid $DTD/urml/urml.dtd"
    fi
    if [ "$TYPE" = "inline" ]; then
	validCall=""
    fi

    command="$XMLLINT --noout $validCall $file"
    log_comm pipeline:validate "$command"

    #  don't validate mmax markable files
    if [ "$TYPE" = "mmax" ]; then
	if $(echo "$file" | grep -q _level.xml); then
	command="true"
	fi
    fi
   
    if $command 2>/dev/null; then
	true
    else 
	error_exit $LINENO "Input format not valid\\nCommand: \"$command\""
    fi
done


#########################################################
# 2. Tool-specific preprocessing
#########################################################


#----------------------------------------
# 2a. TIGER: reverse secondary edges in TIGER data (default: yes)
#----------------------------------------

if [ "$TYPE" = "tiger" -a "$tiger_rev" = "yes" ]; then
       in=$PREP/$NAME.xml.utf8
       out=$PREP/$NAME.xml.utf8.notreversed
       mv $in $out

       in=$PREP/$NAME.xml.utf8.notreversed
       out=$PREP/$NAME.xml.utf8
       prog="$XSLTPROC --novalid"
       styl=$AUX/tiger_reverse.xsl
       command="$prog -o $out $styl $in"
       
       log_comm pipeline:preprocessing "$command"
       if $command; then
	   true
       else
	   error_exit $LINENO "Error(s) while preprocessing\\nCommand: \"$command\""
       fi
fi

#----------------------------------------
# 2b. inline format: create struct/tok prep files
#----------------------------------------

# create separate preparatory struct and tok files

if [ "$TYPE" = "inline" ]; then

    p_root=""
    if [ -n "$STRUCT_ROOT" ]; then
	p_root="-param root $STRUCT_ROOT"
    fi

    base=tok
    layer=const
    
    in=$PREP/$NAME.xml.utf8
    prog="$JAVA org.apache.xalan.xslt.Process "
    styl=$AUX/inline_prep.xsl       
    out=$PREP/$NAME.inline
    
    p_NAME="-param NAME $NAME"
    p_TYPE="-param TYPE $TYPE"
    p_layer="-param layer $layer"
    p_base="-param base $base"
    params="$p_NAME $p_TYPE $p_layer $p_base $p_root"
    
    command="$prog -IN $in -XSL $styl -OUT $out $params"
    
    log_comm pipeline:preprocessing "$command"
    if $command; then
	echo ". preprocessing of inline format"
    else
	error_exit $LINENO "Error(s) while preprocessing\\nCommand: \"$command\""
    fi
fi


#----------------------------------------
#  2c. run stylesheets that make tool-specific input files look more uniform
#----------------------------------------

#  introduce/rename features that are used in common/shared stylesheets,
#+ namely: for all file types:
#+ <text> tag: <_paula_text>
#+ <word> tag: <_paula_word>
#+ for TIGER/URML:
#+ syntax tags: <_paula_const _const_type="..">
#+              <_paula_rel _rel_type="..">
#+ where attributes encode the orig1inal tag names

#  Paula variables
TEXT_NODE=_paula_text
WORD_NODE=_paula_word
CONST_NODE=_paula_const
REL_NODE=_paula_rel


# input file
if [ "$TYPE" = "mmax"  ]; then
    #  for MMAX: only word file is relevant here
    in=$PREP/${NAME}_words.xml.utf8
    #  the other ones: just copy
    for file in $PREP/${NAME}*_level.xml.utf8; do
	log_comm pipeline:preprocessing "cp $file $file.prep"
	cp $file $file.prep
    done
else
    in=$PREP/$NAME.xml.utf8
fi   

out=$PREP/$(basename $in).prep


#----------------------------------------
#  2d. some tools use specific stylesheets
#----------------------------------------

if [ "$TYPE" = "tiger" ]; then
    #  note: originally we transformed word attribute to element content 
    #+ problem however: <t> tags may contain secondary edges, and then
    #+ word content might get mixed up with edges
    #+ hence: keep word attributes + below use extra when-cases for TIGER/@word
    prog="$XSLTPROC --novalid"
    styl=$AUX/tiger_prep.xsl
    command="$prog -o $out $styl $in"
    
elif [ "$TYPE" = "urml" ]; then
    #  add IDs
    prog="$XSLTPROC --novalid"
    styl=$AUX/urml_prep.xsl
    command="$prog -o $out $styl $in"
    
elif [ "$TYPE" = "exmaralda" ]; then
    #  rename source tier by <text> and word events by <word>
    #+ add start/end references to <event>s and add IDs to <word>
    #+ AND: delete empty <event> elements
    prog="$XSLTPROC --novalid"
    styl=$AUX/exmaralda_prep.xsl
    
    p_textID="--stringparam text_nodeID $exm_tier"
    params="$p_textID"
    
    command="$prog -o $out $params $styl $in"
    
else
    #----------------------------------------
    #  apply general renaming stylesheet
    #----------------------------------------
    if  [ "$TYPE" = "inline" ]; then 
	textNode=markList
	wordNode=mark
	constNode=_dummy
	relNode=_dummy
	# special input file
	in=$PREP/$NAME.inline

	
    elif  [ "$TYPE" = "mmax" ]; then 
	textNode=words
	wordNode=word
	constNode=_dummy
	relNode=_dummy
	
    fi
    
    prog="$XSLTPROC --novalid"
    styl=$AUX/general_prep.xsl
    
    p_textNode="--stringparam text_node $textNode"
    p_wordNode="--stringparam word_node $wordNode"
    p_constNode="--stringparam const_node $constNode"
    p_relNode="--stringparam rel_node $relNode"
    params="$p_textNode $p_wordNode $p_constNode $p_relNode"
    
    command="$prog -o $out $params $styl $in"
fi

#  now run command
log_comm pipeline:preprocessing "$command"
if $command; then
    true
else
    error_exit $LINENO "Error(s) while preprocessing\\nCommand: \"$command\""
fi
   

echo ". $TYPE preprocessing: $(basename $out)"


#########################################################
# 3. Read in tagset information
#########################################################

#  read in list of annotation layers that have or will get tagset declarations
#+ plus corresponding declarations
#+ format: each line: layer@@tagset_struct.xml@@tagset_feat.xml

#  HERE:
#+ replace atomic features by complex ones
#+ that already contain link to tagset declaration
#+ e.g. rename 'NN' by 'stts.type_pos.xml#NN'


for file in $PREP/${NAME}*.prep; do
    
    in=$file
    out=$PREP/$(basename $file).tagset

    #  tagset declaration has been specified
    if [ "$tagset_exist" = "yes" ]; then

        #  copy of original input: will be modified during successive loops
	#+ (don't keep intermediate files)
	cp $in $in.tmp

        #  loop over tagsets
        #+ specifications in tagset declarations: separated by '@@'
	while read layerTagset; do  # input: < $tagsetDecl
	    
	    # layer: e.g. "pos"; tagset: e.g. "stts.type_pos.xml"
	    layer=$(echo "$layerTagset" | perl -pe 's/^(.*?)@@(.*?)@@(.*)$/$1/')
	    tagset=$(echo "$layerTagset" | perl -pe 's/^(.*?)@@(.*?)@@(.*)$/$2/')


            #  define different $commands for each file type
            #----------------------------------------
            #  Exmaralda
            #----------------------------------------
	    if [ "$TYPE" = "exmaralda"  ]; then

	        #  attribute name encoded in <tier> element
	        #+ values to be replaced are embedded in <event> tags
		prog="$XSLTPROC --novalid"
		styl=$AUX/exmaralda_tagsetFeatures.xsl
		in_tmp=$in.tmp
		out_tmp=$in.tmp2

		p_layer="--stringparam layer $layer"
		p_tagset="--stringparam tagset $tagset"
		params="$p_layer $p_tagset"

		command="$prog -o $out_tmp $params $styl $in_tmp"
   
            #----------------------------------------
            #  all others
            #----------------------------------------
	    elif [ "$TYPE" != "exmaralda" ]; then
    
	        #  values to be replaced are ordinary attribute values
		prog="$AUX/tagsetFeatures.perl"
		in_tmp=$in.tmp
		out_tmp=$in.tmp2

		command="$PERL $prog $in_tmp $out_tmp $layer $tagset"

	    fi


             #  and then run $command within the loop
	    log_comm pipeline:tagset "$command"
	    if $command; then
	    #  for next loop
		log_comm pipeline:tagset "mv $out_tmp $in_tmp"
		mv $out_tmp $in_tmp
	    else 	
		error_exit $LINENO "Error(s) with tagset-defined features\\nCommand: \"$command\""
	    fi

	    
        #  end of loop for tagset declarations
	done < $tagsetDecl
    
        #  move final output
	log_comm pipeline:tagset "mv $in_tmp $out"
	mv $in_tmp $out
    
	echo ". tagset features renamed: $(basename $out)"
	log_out "Tagset features renamed" "$out" $visual
    

    else
        #  no modifications done (have no tagset declarations)
	log_comm pipeline:tagset "cp $in $out"
	cp $in $out
    fi

done


#########################################################
#  4. Add character information
#########################################################

#  preprocessing step for XPointers: count characters in words
#+ same stylesheet for all file types
#+ (note: no loop needed here since only one MMAX file is concerned)

if [ "$TYPE" = "mmax"  ]; then
    in=$PREP/${NAME}_words.*.tagset
else
    in=$PREP/$NAME.*.tagset
fi   

prog="$SAXON_XSLTPROC "
styl=$AUX/count_chars.xsl
out=$PREP/$NAME.char_count.xml

#  different format for saxon processor
psax_textNode="text_node=$TEXT_NODE"
psax_wordNode="word_node=$WORD_NODE"
params="$psax_textNode $psax_wordNode"

command="$BASH $prog $out $in $styl $params"

log_comm pipeline:count_characters "$command"

if $command; then
    echo ". character counted: $(basename $out)"
else
    error_exit $LINENO "Error(s) while counting characters\\nCommand: \"$command\""
fi
   

log_out "Character counts added" "$out" $visual


#########################################################
#  5. Standoff files: Text
#########################################################

#  variable "layer" is used in standoff XML file as name value
#+ NOTE: same stylesheet for all file types

layer=text
base=dummy  # dummy value here -- not used

in=$PREP/$NAME.char_count.xml
prog="$XSLTPROC --novalid"
styl=$AUX/standoff_text.xsl
out=$STOFF/$TYPE.$NAME.$layer.xml

p_NAME="--stringparam NAME $NAME"
p_TYPE="--stringparam TYPE $TYPE"
p_layer="--stringparam layer $layer"
p_base="--stringparam base $base"
p_textNode="--stringparam text_node $TEXT_NODE"
p_wordNode="--stringparam word_node $WORD_NODE"
params="$p_NAME $p_TYPE $p_layer $p_base $p_textNode $p_wordNode"

command="$prog -o $out $params $styl $in"

log_comm pipeline:standoff_text "$command"

if $command; then
    echo ". standoff $layer: $(basename $out)"
else
    error_exit $LINENO "Error(s) while creating $layer file\\nCommand: \"$command\""
fi

log_out "Standoff $layer" "$out" $visual



#########################################################
#  6. Standoff files: Tokens (referring to text) 
#########################################################

#  all markables/structures are directly or indirectly anchored to tokens
#+ (which are themselves anchored to character positions/ranges)
#+ NOTE: same stylesheet for all file types

layer=tok
base=text

in=$PREP/$NAME.char_count.xml
prog="$XSLTPROC --novalid"
styl=$AUX/standoff_mark.xsl
out=$STOFF/$TYPE.$NAME.$layer.xml

p_NAME="--stringparam NAME $NAME"
p_TYPE="--stringparam TYPE $TYPE"
p_layer="--stringparam layer $layer"
p_base="--stringparam base $base"
p_wordNode="--stringparam word_node $WORD_NODE"
params="$p_NAME $p_TYPE $p_layer $p_base $p_wordNode"
 
command="$prog -o $out $params $styl $in"

log_comm pipeline:standoff_tokens "$command"

if $command; then
    echo ". standoff $layer: $(basename $out)"
else 
    error_exit $LINENO "Error(s) while creating $layer file\\nCommand: \"$command\""
fi

log_out "Standoff $layer" "$out" $visual



#########################################################
#  7. Standoff files: Markables and their annotations
#########################################################

#+ note: we assume that all markable here ultimately refer to tokens as created above
#+ (i.e. with *consecutive* IDs named 'something_1' etc.)
#+ type-specific stylesheets here

#----------------------------------------
#  7a. Exmaralda
#+ create markables + feature annotations in parallel
#----------------------------------------

#  Exmaralda files: all annotations are directly linked to timeline
#+ hence, we have to introduce markables here where annotations are attached to
#+ to avoid ID clashes, we name these markables <feat>Seg, e.g. "posSeg"

#  the stylesheet loops over the @category attributes of all tiers
#+ and first creates a temporary file with markable+feat pairs
#+ next, markables and features are distributed over 2 standoff files
#+ output files are named "exmaralda.<id>.seg.xml" and "exmaralda.<id>.seg_<feat>.xml"


if [ "$TYPE" = "exmaralda" ]; then
    # parameters: for markable files (refering to tokens)
    base=tok
    layer=Seg # capitalized, will be combined with feat names, e.g. "posSeg"
    in=$PREP/$NAME.char_count.xml
    prog="$XSLTPROC --novalid"
    styl=$AUX/exmaralda_createMarkFeat.xsl

    p_NAME="--stringparam NAME $NAME"
    p_TYPE="--stringparam TYPE $TYPE"
    p_layer="--stringparam layer $layer"
    p_base="--stringparam base $base"
    #  individual files-out: 
    #+ determined in stylesheet via xalan:write (in directory $EXM)
    p_dirOut="--stringparam dir_out $EXM"
    params="$p_NAME $p_TYPE $p_layer $p_base $p_dirOut"

    command="$prog $params $styl $in"
    log_comm pipeline:exmaralda_markablesFeatures "$command"
	
    if $command; then
	true
    else 
	error_exit $LINENO "Error(s) while creating markFeat file\\nCommand: \"$command\""
    fi
    
    #  now split marks and feats
    for file in $EXM/markFeat.*; do
        # parameters: for feature files (refering to segments)
	in=$file
	prog="$XSLTPROC --novalid"
	styl=$AUX/exmaralda_splitMarkFeat.xsl

	p_NAME="--stringparam NAME $NAME"
	p_TYPE="--stringparam TYPE $TYPE"
	p_layer="--stringparam layer $layer"
	p_base="--stringparam base $base"
        #  individual files-out: 
	#+ determined in stylesheet via xalan:write (in directory $STOFF)
	p_dirOut="--stringparam dir_out $STOFF"
	params="$p_NAME $p_TYPE $p_layer $p_base $p_dirOut"

	command="$prog $params $styl $in"
	log_comm pipeline:exmaralda_markables_features "$command"
	
	if $command; then
	    true
	else 
	    error_exit $LINENO "Error(s) while creating mark/feat standoff files\\nCommand: \"$command\""
	fi
    done

    # enumerate all files for log files
    echo ". standoff layers: "
    for file in $STOFF/$TYPE.$NAME.*Seg_*; do
	echo "  - $(basename $file)"
	log_out "Standoff layers" "$file" $visual
    done

fi


#----------------------------------------
#  7b. TIGER/URML feature annotations (on tokens)
#----------------------------------------

if [  $TYPE = tiger -o $TYPE = urml ]; then 

    in=$PREP/$NAME.char_count.xml
    base=tok
    prog="$XSLTPROC --novalid"
    styl=$AUX/tigerUrml_mark_generalfeat.xsl

    p_NAME="--stringparam NAME $NAME"
    p_TYPE="--stringparam TYPE $TYPE"
    p_layer="--stringparam layer dummy"
    p_base="--stringparam base $base"
    p_featNode="--stringparam feat_node $WORD_NODE"
    p_dirOut="--stringparam dir_out $STOFF"
    params="$p_NAME $p_TYPE $p_layer $p_base $p_featNode $p_dirOut"

    command="$prog $params $styl $in"
    log_comm pipeline:standoff_token_features "$command"
	
    if $command; then
	echo ". standoff file(s): $NAME.${base}_<feat>.xml"
    else 
	error_exit $LINENO "Error(s) while creating $base feature files\\nCommand: \"$command\""
    fi
    

    for file in $STOFF/$TYPE.$NAME.${base}_*; do
	log_out "Standoff $base_<feat> layers" "$file" $visual
    done

fi



#----------------------------------------
#  7c. URML
#+ create extra markable file for segment markables
#----------------------------------------

if [ "$TYPE" = "urml" ]; then

    base=tok
    layer=discUnit

    in=$PREP/$NAME.char_count.xml
    prog="$XSLTPROC --novalid"
    styl=$AUX/urml_seg.xsl
    out=$STOFF/$TYPE.$NAME.$layer.xml

    p_NAME="--stringparam NAME $NAME"
    p_TYPE="--stringparam TYPE $TYPE"
    p_layer="--stringparam layer $layer"
    p_base="--stringparam base $base"
    params="$p_NAME $p_TYPE $p_layer $p_base"

    command="$prog -o $out $params $styl $in"
    log_comm pipeline:urml_segments "$command"

    if $command; then
	echo ". standoff seg: $(basename $out)"
    else 
	error_exit $LINENO "Error(s) while creating standoff for segments\\nCommand: \"$command\""
    fi
    

    #----------------------------------------
    #  URML: in case there are attributes annotated to <segments>
    #----------------------------------------

    in=$PREP/$NAME.char_count.xml
    base=discUnit
    prog="$XSLTPROC --novalid"
    styl=$AUX/tigerUrml_mark_generalfeat.xsl

    p_NAME="--stringparam NAME $NAME"
    p_TYPE="--stringparam TYPE $TYPE"
    p_layer="--stringparam layer dummy"
    p_base="--stringparam base $base"
    p_featNode="--stringparam feat_node segment"
    p_dirOut="--stringparam dir_out $STOFF"
    params="$p_NAME $p_TYPE $p_layer $p_base $p_featNode $p_dirOut"

    command="$prog $params $styl $in"
    log_comm pipeline:standoff_token_features "$command"
	
    if $command; then
	echo ". standoff file(s): $NAME.${base}_<feat>.xml"
    else 
	error_exit $LINENO "Error(s) while creating $base feature files\\nCommand: \"$command\""
    fi
    

    for file in $STOFF/$TYPE.$NAME.${base}_*; do
	log_out "Standoff $base_<feat> layers" "$file" $visual
    done

fi
  

#----------------------------------------
#  7d. MMAX
#----------------------------------------

if  [ $TYPE = mmax ]; then

    #  for MMAX: 

    #  differing input files (= loop on mmax-standoff _level annotation files)
    #+ i.e. one loop concerns one mark_type, e.g. primmark

    #----------------------------------------
    #  loop to create annotation files
    #----------------------------------------

    for file in $PREP/$NAME*_level.*.prep; do

	# e.g. $mark_type = primmark, $file_name = mmax.primmark
	mark_type=$(echo "$file" | perl -pe 's/^.*_([^_]*)_level.xml.*/$1/')
	file_name=$NAME.$mark_type

        #----------------------------------------
        #  1. create segment (markable) file (refering to toks)
        #----------------------------------------

	# note: this mmax-markable name *Seg is used in other places as well
	# e.g. in $AUX/mmax_spans.perl!
	layer=${mark_type}Seg
	base=tok
	    
	in=$file
	prog="$XSLTPROC --novalid"
	styl=$AUX/mmax_segments.xsl
	out=$MMAX/$NAME.$layer.xml.mark
	
	p_NAME="--stringparam NAME $NAME"
	p_TYPE="--stringparam TYPE $TYPE"
	p_layer="--stringparam layer $layer"
	p_base="--stringparam base $base"
	params="$p_NAME $p_TYPE $p_layer $p_base"

	command="$prog -o $out $params $styl $in"

	log_comm pipeline:mmax_segments "$command"
	if $command; then
	    true
	else
	    error_exit $LINENO "Error(s) while creating $layer file\\nCommand: \"$command\""
	fi


	# now check whether we create multifeats or not
	if [ "$multFeat" = "yes" ]; then

        #----------------------------------------
        # 2. create annotation files (multiFeats)
        #----------------------------------------
	#  note: we still look at one mark_type only (e.g. primmark)

	    base=${mark_type}Seg
	    layer=${mark_type}Seg_multiFeat

	    in=$file
	    prog="$XSLTPROC --novalid"
	    styl=$AUX/mmax_feat.xsl
	    out=$MMAX/$NAME.${layer}.xml.feat
	    
	    p_NAME="--stringparam NAME $NAME"
	    p_TYPE="--stringparam TYPE $TYPE"
	    p_layer="--stringparam layer $layer"
	    p_base="--stringparam base $base"
	    params="$p_NAME $p_TYPE $p_layer $p_base"
	    
	    command="$prog -o $out $params $styl $in"
	    log_comm pipeline:mmax_features "$command"
	    
	    if $command; then
		true
	    else
		error_exit $LINENO "Error(s) while creating $attr feature files\\nCommand: \"$command\""
	    fi
	    

	else 

        #----------------------------------------
        #  3. ALTERNATIVE: NO MULTIFEATS
        #----------------------------------------

        #----------------------------------------
	#  3a. extract list of all attributes that are annotated at some markable
        #----------------------------------------

	    in=$file
	    prog="$XSLTPROC --novalid"
	    styl=$AUX/markStruct_extractAttrs.xsl
	    out=$MISC/$mark_type.attrList.txt
	    
	    log_comm pipeline:attrList "$command"
	    command="$prog -o $out $styl $in"
	    
	    if $command; then
		true
	    else
		error_exit $LINENO "Error(s) while extracting MMAX features\\nCommand: \"$command\""
	    fi
	    
	#  now check whether any attribute has been extracted
	#  '-s file': True if file exists and has a size greater than zero.
	    
	    if [ -s $out ]; then
	    #  if there are any attributes, sort list of attributes
	    #+ and delete some irrelevant ones
		
		in=$out
		prog=$AUX/attrList.perl 
		out=$MISC/$mark_type.attrSort.txt
		command="$PERL $prog $in $out"
		
		log_comm pipeline:attrList "$command"
		
		if $command; then
		    echo ". attr list extracted: $(basename $out)"
		else 
		    error_exit $LINENO "Error(s) while extracting MMAX features\\nCommand: \"$command\""
		fi
	    fi
	    
	#  now test again if attributes are left
	    if [ -s $out ]; then
		
            #----------------------------------------
	    # 3b. next create annotation files
            #----------------------------------------
	    #  note: we still look at one mark_type only (e.g. primmark)
		
		attrList="$(cat $out)"
		
		for attr in $attrList; do
		    base=${mark_type}Seg
		    layer=${mark_type}Seg_$attr
		    
		    in=$file
		    prog="$XSLTPROC --novalid"
		    styl=$AUX/markStruct_feat.xsl
		    out=$MMAX/$NAME.${layer}.xml.feat
		    
		    p_NAME="--stringparam NAME $NAME"
		    p_TYPE="--stringparam TYPE $TYPE"
		    p_layer="--stringparam layer $layer"
		    p_base="--stringparam base $base"
		    p_featNode="--stringparam feat_node markable"
		    p_attr="--stringparam attr $attr"
		    params="$p_NAME $p_TYPE $p_layer $p_base $p_featNode $p_attr"
		    
		    command="$prog -o $out $params $styl $in"
		    log_comm pipeline:mmax_features "$command"
		    
		    if $command; then
			true
		    else 
			error_exit $LINENO "Error(s) while creating $attr feature files\\nCommand: \"$command\""
		    fi
		    
		done  #  for attr in $attr_list; do
		
	    fi  # if [ -s $out ]; then
	    
	fi
    done  # for file in $PREP/$NAME*_level.xml; do

	

    #  after having processed all mark_types
    #+ now do postmodifications (XPointers, virtual markables)

    #----------------------------------------
    #  4. modify link-valued attributes
    #----------------------------------------
	
    #  after having created all attribute files
    #+ do some postmodifications of linking attributes:
    #+ use XPointer syntax for ranges etc.

    #  1. for mark files: first do XPointer renaming
    for file in $MMAX/*.mark; do

	in=$file
	prog="$AUX/mmax_replaceSpans.perl"
	out=$file.Xpointers
	command="$PERL $prog $in $out"
    
	log_comm pipeline:mmax_segments "$command"

	if $command; then
	    echo ". (temporary) segment file: $(basename $out)"
	else 
	    error_exit $LINENO "Error(s) while creating xpointers\\nCommand: \"$command\""
	fi

    done


    #  2. for feat files: first do XPointer renaming (like above)
    for file in $MMAX/*.feat; do

	in=$file
	prog="$AUX/mmax_replaceSpans.perl"
	out=$file.Xpointers
	command="$PERL $prog $in $out"
    
	log_comm pipeline:mmax_segments "$command"

	if $command; then
	    true
	else 
	    error_exit $LINENO "Error(s) while creating xpointers\\nCommand: \"$command\""
	fi

        #  next: create extra "virtual" markables if pointer target is a 
        #+ range/discontinuous etc. (concerns <feat> files only but extra
	#+ markables have to be inserted into ordinary mark files)
        #  note: we assume that feature ranges only point to one markable file
	#+ i.e. we can use local xlink:hrefs for virtual markables

	#  first determine corresponding mark-file name by value of xml_base attribute
	inFeat=$out
	inMark=$(grep -Eo 'xml_base="[^"]+"' $inFeat | \
	    perl -pe 's/xml_base="mmax.([^"]+)"/$1/' )
	inMark=$MMAX/$inMark.mark.Xpointers

	prog="$AUX/mmax_virtualSeg.perl"
	outFeat=$STOFF/$TYPE.$(basename $inFeat | perl -pe 's/.feat.Xpointers//' )
	outMark=$inMark.tmp
	
	command="$PERL $prog $inFeat $inMark $outFeat $outMark"
	
	log_comm pipeline:mmax_segments "$command"
	if $command; then
	    #  for next loop
	    mv $outMark $inMark
	else 
	    error_exit $LINENO "Error(s) while creating virtual markables\\nCommand: \"$command\""
	fi

    done

    #  copy final version of markables to STOFF directory
    for file in $MMAX/*.mark.Xpointers; do
	out=$STOFF/$TYPE.$(basename $file | perl -pe 's/.mark.Xpointers//' )
	log_comm pipeline:mmax_segments "cp $file $out"
	cp $file $out
    done

    echo ". markables and features for mmax"

    #  list of files for log file
    for file in $STOFF/$TYPE.$NAME.*_*; do
	log_out "Standoff $base_<feat> layers" "$file" $visual
    done

fi  # if  [ $TYPE = mmax ]; then



#########################################################
#  8. Standoff files: Tree/Graph annotations (syntax, RST,...)
#########################################################

#  we first reorganize TIGER/URML to some degree
#+ so that we then can apply the same stylesheets for creating standoff

#----------------------------------------
#  8a. TIGER
#+ preparatory stylesheets for renumbering and restructuring
#----------------------------------------

if [ "$TYPE" = "tiger" ]; then

    #  first stylesheet: reverse secondary edges
    #+ these variables go into names of IDs, e.g. 'rel_5', and in the type attribute
    base=tok
    layer=const
    rel=rel

    in=$PREP/$NAME.char_count.xml
    prog="$XSLTPROC --novalid"
    out=$SYNTAX/structFeat.$layer.tmp
    styl=$AUX/tiger_syntaxPrep1.xsl

    p_NAME="--stringparam NAME $NAME"
    p_TYPE="--stringparam TYPE $TYPE"
    p_layer="--stringparam layer $layer"
    p_base="--stringparam base $base"
    p_relName="--stringparam rel_name ${rel}_"
    params="$p_NAME $p_TYPE $p_layer $p_base $p_relName"

    command="$prog -o $out $params $styl $in"

    log_comm pipeline:tiger_preparations "$command"

    if $command; then
	true
    else 
	error_exit $LINENO "Error(s) while preparing for $layer files\\nCommand: \"$command\""
    fi

    #  second stylesheet: create struct and feat files
    in=$out
    styl=$AUX/tiger_syntaxPrep2.xsl
    out=$SYNTAX/structFeat.$layer.xml
    command="$prog -o $out $styl $in"

    log_comm pipeline:tiger_preparations "$command"

    if $command; then
	echo ". preparing for $layer files: $(basename $out)"
    else 
	error_exit $LINENO "Error(s) while preparing for $layer files\\nCommand: \"$command\""
    fi
fi


#----------------------------------------
#  8b. URML
#+ preparatory stylesheets for renaming and adding start/end info
#----------------------------------------

if [ "$TYPE" = "urml" ]; then

    base=discUnit
    layer=const
    rel=rel

    in=$PREP/$NAME.char_count.xml
    prog="$XSLTPROC --novalid"
    styl=$AUX/urml_syntaxPrep.xsl
    out=$SYNTAX/structFeat.$layer.xml

    p_NAME="--stringparam NAME $NAME"
    p_TYPE="--stringparam TYPE $TYPE"
    p_layer="--stringparam layer $layer"
    p_base="--stringparam base $base"
    p_relName="--stringparam rel_name ${rel}_"
    params="$p_NAME $p_TYPE $p_layer $p_base $p_relName"
		
    command="$prog -o $out $params $styl $in"
    log_comm pipeline:urml_segments "$command"

    if $command; then
	echo ". preparing for $layer files: $(basename $out)"
    else 
	error_exit $LINENO "Error(s) while preparing for $layer files\\nCommand: \"$command\""
    fi

fi


#----------------------------------------
#  8c. TIGER+URML: 
#+ now build <struct> elements for constituents
#----------------------------------------

if [ "$TYPE" = "tiger" -o "$TYPE" = "urml" ]; then

    #---------------------------    
    #  first extract <struct>s
    #---------------------------    

    if [ "$TYPE" = "tiger" ]; then 
	base=tok
	layer=const
	layer_in=const

    elif [ "$TYPE" = "urml" ]; then 
	base=discUnit
	layer=const
	layer_in=const
    fi

    in=$SYNTAX/structFeat.const.xml
    prog="$XSLTPROC --novalid"
    styl=$AUX/standoff_struct.xsl
    out=$STOFF/$TYPE.$NAME.$layer.xml

    p_NAME="--stringparam NAME $NAME"
    p_TYPE="--stringparam TYPE $TYPE"
    p_layer="--stringparam layer $layer"
    p_base="--stringparam base $base"
    params="$p_NAME $p_TYPE $p_layer $p_base"
		
    command="$prog -o $out $params $styl $in"
    log_comm pipeline:struct_elements "$command"

    if $command; then
	echo ". standoff $layer: $(basename $out)"
    else
	error_exit $LINENO "Error(s) while creating $layer files\\nCommand: \"$command\""
    fi

    log_out "Standoff $layer" "$out" $visual

 
    #---------------------------    
    #  next extract <struct> features
    #---------------------------    

    in=$SYNTAX/structFeat.const.xml
    base=const
    prog="$XSLTPROC --novalid"
    styl=$AUX/tigerUrml_struct_generalfeat.xsl

    p_NAME="--stringparam NAME $NAME"
    p_TYPE="--stringparam TYPE $TYPE"
    p_layer="--stringparam layer dummy"
    p_base="--stringparam base $base"
    p_dirOut="--stringparam dir_out $STOFF"

    for featNode in "$CONST_NODE" "$REL_NODE"; do
	p_featNode="--stringparam feat_node $featNode"
	params="$p_NAME $p_TYPE $p_layer $p_base $p_featNode $p_dirOut"

	command="$prog $params $styl $in"
	log_comm pipeline:standoff_struct_features "$command"
	
	if $command; then
	    true
	else 
	    error_exit $LINENO "Error(s) while creating $base feature files\\nCommand: \"$command\""
	fi
    done

    for file in $STOFF/$TYPE.$NAME.${base}_*; do
	log_out "Standoff $base_<feat> layers" "$file" $visual
    done
    
fi

#########################################################
#  9. Standoff files: Generic inline
#########################################################

#----------------------------------------
#  1. struct: copy struct file and delete irrelevant attributes
#----------------------------------------

if [ "$TYPE" = "inline" ]; then
    base=tok
    layer=const

    in=$PREP/$NAME.inline
    prog="$XSLTPROC --novalid"
    styl=$AUX/inline_struct.xsl
    out=$STOFF/$TYPE.$NAME.const.xml

    p_NAME="--stringparam NAME $NAME"
    p_TYPE="--stringparam TYPE $TYPE"
    p_layer="--stringparam layer $layer"
    p_base="--stringparam base $base"
    params="$p_NAME $p_TYPE $p_layer $p_base"

    command="$prog -o $out $params $styl $in"

    if $command; then
	true
    else 
	error_exit $LINENO "Error(s) while deleting attributes\\nCommand: \"$command\""
    fi


#----------------------------------------
#  2. <feat> elements for categories etc.
#+ (pointing to <struct>s)
#----------------------------------------

#  note: in contrast to TIGER/URML, we don't assume here that all nodes
#+ are annotated with the same feature set (e.g. all tokens having
#+ pos annotations) -> hence, we first collect all annotated features

    for mark_type in "mark" "struct"; do

	in=$PREP/$NAME.inline

	prog="$XSLTPROC --novalid"
	styl=$AUX/${mark_type}_extractAttrs.xsl
	out=$MISC/${mark_type}_attrList.txt

	log_comm pipeline:attrList "$command"
	command="$prog -o $out $styl $in"
    
	if $command; then
	    true
	else
	    error_exit $LINENO "Error(s) while extracting inline features\\nCommand: \"$command\""
	fi
	
        # now check whether any attribute has been extracted
	#  '-s file': True if file exists and has a size greater than zero.
	
	if [ -s $out ]; then
	    #  if there are any attributes, sort list of attributes
	    #+ and delete some irrelevant ones
	    
	    in=$out
	    prog=$AUX/attrList.perl 
	    out=$MISC/${mark_type}_attrSort.txt
	    command="$PERL $prog $in $out"

	    log_comm pipeline:attrList "$command"
	    
	    if $command; then
		echo ". attr list extracted: $(basename $out)"
	    else 
		error_exit $LINENO "Error(s) while extracting MMAX features\\nCommand: \"$command\""
	    fi
	fi
	
	#  now test again if attributes are left
	if [ -s $out ]; then
	    
            #----------------------------------------
	    # 3. next create annotation files
            #----------------------------------------

	    attrList="$(cat $out)"

	    for attr in $attrList; do

		if [ "$mark_type" = "mark" ]; then
		    base=tok
		    layer=tok_$attr
		    p_featNode="--stringparam feat_node mark"

		else
		    base=const
		    layer=const_$attr
		    p_featNode="--stringparam feat_node struct"
		fi

		in=$PREP/$NAME.inline
		prog="$XSLTPROC --novalid"
		styl=$AUX/markStruct_feat.xsl
		out=$STOFF/$TYPE.$NAME.${layer}.xml

		p_NAME="--stringparam NAME $NAME"
		p_TYPE="--stringparam TYPE $TYPE"
		p_layer="--stringparam layer $layer"
		p_base="--stringparam base $base"
		p_attr="--stringparam attr $attr"
		params="$p_NAME $p_TYPE $p_layer $p_base $p_featNode $p_attr"

		command="$prog -o $out $params $styl $in"
		log_comm pipeline:features "$command"

		if $command; then
		    true
		else 
		    error_exit $LINENO "Error(s) while creating $attr feature files\\nCommand: \"$command\""
		fi

	    done  #  for attr in $attr_list; do
	    
	fi  # if [ -s $out ]; then

    done # for mark_type
fi


#########################################################
#  10. Standoff files: Meta information
#########################################################


if [ "$TYPE" = "exmaralda" ]; then

    in=$PREP/$NAME.xml.utf8
    out=$MISC/meta.txt
    prog="$XSLTPROC --novalid"
    styl=$AUX/exmaralda_metainfo.xsl
    
    command="$prog -o $out $styl $in"
    log_comm pipeline:standoff_metainfo "$command"
    
    if $command; then
	true
    else 
	error_exit $LINENO "Error(s) while extracting meta info\\nCommand: \"$command\""
    fi
    
    if [ ! -f "$out" ]; then 
	#  no meta info could be extracted
	echo ". no meta information found"
	meta_exist="no"
    else
	echo ". meta info extracted"
	meta_exist="yes"
    fi
fi


#########################################################
#  11. Standoff files: Create meta-info  and anno-set files
#########################################################
#+ NOTE: anno files could actually be constructed by end user
#+ and could be used to group arbitrary annotations
#
#  NOTE: we simply look for type and xml:base attributes
#+ and group files that refer to each other by the xml:base attribute
#+ (i.e. features are grouped with "their" markables/structures)
#+ exception: tagsets are read off from the tagset declaration file


#----------------------------------------
#  then collect all annotation file names
#----------------------------------------

for file in $STOFF/$TYPE.$NAME*.xml; do

    in=$file
    prog="$XSLTPROC --novalid"
    styl=$AUX/extract_annoGroups.xsl
    out=$MISC/annos.txt
  
    log_comm pipeline:attrList "$command"
    command="$prog $styl $in"
	
    echo -n "FILE:$(basename $file)@@" >> $out

    if $command >> $out; then
	true
    else
	error_exit $LINENO "Error(s) while extracting annoGroup features\\nCommand: \"$command\""
    fi

done


#----------------------------------------
#  now group annotations
#----------------------------------------

prog="$AUX/anno_files.perl"
inAnnos=$MISC/annos.txt

if [ "$meta_exist" = "yes" ]; then
    inMeta=$MISC/meta.txt
else
    inMeta="none"
fi

if [ "$tagset_exist" = "yes" ]; then
    inTagsets=$tagsetDecl
else
    inTagsets="none"
fi

outAnnoSet=$STOFF/$TYPE.$NAME.anno.xml
outAnnoFeat=$STOFF/$TYPE.$NAME.anno_feat.xml
command="$PERL $prog $inMeta $inAnnos $inTagsets $outAnnoSet $outAnnoFeat $TYPE $NAME"

if $command; then
    echo ". anno files created"
else 
    error_exit $LINENO "Error(s) while creating anno files\\nCommand: \"$command\""
fi


#----------------------------------------
# meta info files
#----------------------------------------
#+ note: since meta info points to <struct>s in annoFile,
#+ we can construct the meta files only after annoSet construction

if [ "$meta_exist" = "yes" ]; then

   inMeta=$MISC/meta.txt
   
    while read attrVal; do  # input: $MISC/meta.txt
       #  hacky way of pulling out layer and tagset name ...
	attr=$(echo "$attrVal" | perl -pe 's/^(.*?)::::(.*)/$1/')
	value=$(echo "$attrVal" | perl -pe 's/^(.*?)::::(.*)/$2/')


        #  1. header for meta files
	prog="$AUX/paula_header.perl"
	out=$STOFF/$TYPE.$NAME.meta_$attr.xml
	sfbtype="feat";mytype="$attr";base="anno"
	command="$PERL $prog $TYPE $sfbtype $mytype $NAME $base $out"
	$command


        #  2. features
        #+ special: meta info points to all other <struct>s in anno file
        #+ TODO: except for own <struct> element!
	for anno in $(grep -Eo 'anno_[0-9]+' $STOFF/$TYPE.$NAME.anno.xml); do
	    echo -e "<feat xlink:href=\"#$anno\" value=\"$value\"/>" >> $STOFF/$TYPE.$NAME.meta_$attr.xml
	done

	cat $AUX/footer_feat >> $STOFF/$TYPE.$NAME.meta_$attr.xml

    done < $inMeta
    
fi


#########################################################
#  12. Standoff files: Replace certain attributes/values
#########################################################

prog="$AUX/replace_specialChars.perl"

for file in $STOFF/$TYPE.$NAME*.xml; do
    in=$file
    out=$STOFF_FINAL/$(basename $file)
    command="$PERL $prog $in $out"

    log_comm pipeline:clean_up "$command"

    if $command; then
	true
    else 
	error_exit $LINENO "Error(s) while replacing special characters in $file\\nCommand: \"$command\""
    fi
done

echo ". special characters replaced"


#########################################################
#  13. Standoff files: Check for validity
#########################################################

#  first check XML validity
for file in $STOFF_FINAL/*.xml; do
    prog="$XMLLINT --valid --noout"
    command="$prog $file"
    log_comm pipeline:xmlvalid "$command"

    if ! $command; then 
	error_exit $LINENO "Error(s) while checking XML format of $file\\nCommand: \"$command\""
    fi
done

#  next check xlink:href attributes
for file in $STOFF_FINAL/*.xml; do
    prog="$AUX/check_xml.perl"
    command="$PERL $prog $file"
    log_comm pipeline:xmlvalid "$command"

    if ! $command; then 
	error_exit $LINENO "Error(s) while checking XML format of $file\\nCommand: \"$command\""
    fi
done

echo ". XML files checked for well-formedness";

log_comm pipeline:final "cp $STOFF_FINAL/* $DIR_OUT"
command="cp $STOFF_FINAL/* $DIR_OUT"
if ! $command; then 
    error_exit $LINENO "Error(s) while copying files to output dir\\nCommand: \"$command\""
fi

echo ". standoff output files saved to \"$DIR_OUT/\""



#----------------------------------------
#  clean up
#----------------------------------------

if [ -z "$keep_files" ]; then 
    #  remove intermediate representations
    rm -rf $WORK
    echo ". intermediate representations removed"
else
    echo ". intermediate representations kept in \"$WORK/\""
fi


exit 0
