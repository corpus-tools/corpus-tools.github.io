cp *.tok.* ats-pcc11-coref/
cp *.tok.* ats-pcc11-is/
cp *.tok.* ats-pcc11-rst/
cp *.tok.* ats-pcc11-tiger/
cp *text* ats-pcc11-coref/
cp *text* ats-pcc11-is/
cp *text* ats-pcc11-rst/
cp *text* ats-pcc11-tiger/
cp *dtd ats-pcc11-coref/
cp *dtd ats-pcc11-is/
cp *dtd ats-pcc11-rst/
cp *dtd ats-pcc11-tiger/
mv mmax* ats-pcc11-coref/
mv exmaralda* ats-pcc11-is/
mv urml* ats-pcc11-rst/
mv tiger* ats-pcc11-tiger/
mv stts* ats-pcc11-tiger/

