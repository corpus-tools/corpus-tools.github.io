/*
	(c) Tillmann Wegst 2003
*/
var historyObj = new Array();	// f�hrt alle History-Objekte

function History(id,idPfeilOben,idPfeilUnten) {
	this.element=document.getElementById(id);	// mit History ausgestattetes Texteingabefeld
	this.spanPfeilOben=document.getElementById(idPfeilOben);	// span mit Pfeil-oben-Grafik
	this.spanPfeilUnten=document.getElementById(idPfeilUnten);	// span mit Pfeil-unten-Grafik
	this.spanPfeilOben.style.borderBottom=this.spanPfeilUnten.style.borderBottom="1px solid";
	this.spanPfeilOben.style.borderRight=this.spanPfeilUnten.style.borderRight="1px solid";
	historyObj[id]=this;	// in Array eintragen
	this.eingabe = new Array();	// Array mit vergangenen Eingaben
	this.eingabe[0]="";	// Leerer Eintrag am Ende
	this.p=0;	// Laufvariable zur Iteration �ber den History-Eintr�gen
	this.prev=_histPrev;
	this.next=_histNext;
	this.keyPressed=_histKeyPressed;
	this.nimm=_histNimm;
	this.zeigAlle=_histZeigAlle;	// blo� f�r Debugging
	//this.priorisiere=_histPriorisiere;
	//this.gibPositionVon=_histGibPositionVon;
	//this.gibtEs=_histGibtEs;
	this.gibEingabeArrayFuerAufnahme=_histGibEingabeArrayFuerAufnahme;
	this.setzePfeilStyles=_histSetzePfeilStyles;
	this.setzePfeilStyles();
}

/* History-Methode; Elemente mit den Pfeilchen erhalten Stil, je nach Aktivierbarkeit */
function _histSetzePfeilStyles() {
	var cHI="#000000";	// Aktiv-Farben, color und
	var bgHI="#ccccff";	// backgroundColor
	var cLO="#999999";	// Inaktiv-Farben, color und
	var bgLO="#aaaaaa";	// backgroundColor
	var s=this.spanPfeilOben.style;	// Element mit Pfeil nach oben
	if (this.p>0) {	// �lterer Eintrag da?
		s.color=cHI; s.backgroundColor=bgHI; s.cursor="pointer";
	}
	else {
		s.color=cLO; s.backgroundColor=bgLO; s.cursor="auto";
	}
	s=this.spanPfeilUnten.style;	// Element mit Pfeil nach unten
	if (this.p<this.eingabe.length-1) {	// neuerer Eintrag da?
		s.color=cHI; s.backgroundColor=bgHI; s.cursor="pointer";
	}
	else {
		s.color=cLO; s.backgroundColor=bgLO; s.cursor="auto";
	}
}


/*
	Liefert einen neuen Array mit allen Eingaben au�er
		- 'eintrag' (es wird case-insensitiv verglichen)
		- dem leeren String am Ende
*/
function _histGibEingabeArrayFuerAufnahme(eintrag) {
	var neu = new Array();
	var i;
	var e;
	for (i=0; i<this.eingabe.length; ++i) {
		e=this.eingabe[i];
		if (istLeerOderSpace(e)) continue;
		if (e.toLowerCase()==eintrag.toLowerCase()) continue;
		neu[neu.length]=e;
	}
	return neu;
}


/*
	History-Methode zum Eintragen der Eingaben
*/
function _histNimm(eingabe,prev) {
		// wenn's nix is, mach ma nix damit
	if (istLeerOderSpace(eingabe)) return false;

	this.eingabe=this.gibEingabeArrayFuerAufnahme(eingabe);
	this.eingabe[this.eingabe.length]=eingabe;
	this.eingabe[this.eingabe.length]="";
	this.p=this.eingabe.length-1;
	this.element.value="";

	//this.zeigAlle();
	if (prev) this.prev();
	this.setzePfeilStyles();
	return true;
}


/*
	nur f�r Debugging, zeigt den Inhalt
	der History und die Position des Cursors
*/
function _histZeigAlle() {
	var s="";
	var x;
	for (x=0; x<this.eingabe.length; ++x) {
		s+=x+"="+this.eingabe[x];
		if (x==this.p) s+=" <-p";
		s+="\n";
	}
	alert(s);
}


/* History-Methode zum Holen der n�chst-�lteren Eingabe */
function _histPrev() {
	// this.zeigAlle();
	if (this.p>0) {	// falls es ein Zur�ck gibt
			// wenn aktuell das letzte Element (d.h. die neue Eingabe) gezeigt (und bearbeitet) wird
		if (this.p==this.eingabe.length-1)
				// den Zustand in der Eingabe in das letzte Listenelement sichern
			this.eingabe[this.p]=this.element.value;
		//this.element.innerText=this.eingabe[--this.p];
			// und nun zur�ckgehen und die �ltere Eingabe anzeigen
		this.element.value=this.eingabe[--this.p];
	}
	this.setzePfeilStyles();
}

/* History-Methode zum Holen der n�chst-j�ngeren Eingabe */
function _histNext() {
	// this.zeigAlle();
	if (this.p < this.eingabe.length-1) {	// falls es ein Vorw�rts gibt
		//this.element.innerText=this.eingabe[++this.p];
		this.element.value=this.eingabe[++this.p];
	}

	this.setzePfeilStyles();
}

/* History-Methode, aufzurufen, wenn Taste im Eingabefeld gedr�ckt. Bewirkt Ende des Iterierens. */
function _histKeyPressed() {
	this.p=this.eingabe.length-1;
	this.setzePfeilStyles();
}

/* History-Funktionen, Handler von Klicks bzw. Tastendrucken */

/*
	Aufzurufen, wenn die n�chst-�ltere Eingabe gezeigt werden soll.
	'pos' identifiziert das History-Obj, in der Reihenfolge der Konstruktion, 0..n
*/
function histPrev(id) {
	historyObj[id].prev();
}

/*
	Aufzurufen, wenn die n�chst-j�ngere Eingabe gezeigt werden soll.
	'pos' identifiziert das History-Obj, in der Reihenfolge der Konstruktion, 0..n
*/
function histNext(id) {
	historyObj[id].next();
}

/*
	Wird aufgerufen, wenn in einem Eingabefeld, dem eine Eingabe-History
	zugeordnet ist, eine Taste gedr�ckt wurde.
	Der Parameter nennt als Zahl die Position des zugeh�rigen History-
	Objekts auf dem globalen Array mit allen History-Objekten.
*/
function histKeyPressed(id) {
	historyObj[id].keyPressed();
}


/*
	Wird aufgerufen, wenn eine Eingabe gemacht wird.
	Dient dazu, die History auf den ggf. ver�nderten
	Stand zu bringen
*/
function histNimm(id,eingabe) {
	return historyObj[id].nimm(eingabe,true);
}


/*
	Teilt mit, ob 's' nur aus Space besteht
*/
function istLeerOderSpace(s) {
	return /^[ \t\n\r]*$/.test(s);
}


/*
	Schiebt das Element an der angegebenen Position
	ans Ende der Liste (aber VOR das wirkliche Ende mit dem
	leeren String!)
*/
/* function _histPriorisiere(pos) {
	var wert=this.eingabe[pos];	// der zu priorisierende Wert
	var len=this.eingabe.length;
		// die dem zu priorisierenden Wert nachfolgenden Werte
		// um 1 nach links r�cken
	var q=pos+1;
	while (q < len-1)
		this.eingabe[pos++]=this.eingabe[q++];
		// und den z. p. W. nun hinten einf�gen
	this.eingabe[pos]=wert;
}*/


/*
	Teilt mit, ob es 'eingabe' bereits in der History gibt
*/
/*function _histGibtEs(eingabe) {
	return this.gibPositionVon(eingabe)>-1;
}*/


/*
	Liefert die Position von 'eingabe' in der History.
	Gibt es 'eingabe' nicht, wird -1 geliefert
*/
/* function _histGibPositionVon(eingabe) {
	var i;
	var len=this.eingabe.length;
	for (i=0; i<len; ++i) {
		if (this.eingabe[i]==eingabe)
			return i;
	}
	return -1;
}*/


/* Und so wird es benutzt:

<head>
...
	<!-- history-Script reinlinken -->
<script language="javascript" type="text/javascript" src="history.js"></script>

</head>
<body>

<form>
	<table>
	<tr><td>
		<!-- Textfeld, das mit History versehen wird, mit ID und Fkts.aufruf -->
	<input id=textH type=text name=x onKeyPress='histKeyPressed("textH")'>
	<td>
		<!-- spans mit Pfeil-Gifs, mit denen in der History gebl�ttert wird -->
	<span id=textHPrev onclick="histPrev('textH')"><img src="pfeilspino.gif" alt=Fr�here></span><br>
	<span id=textHNext onclick="histNext('textH')"><img src="pfeilspinu.gif" alt=Sp�tere></span>
	</td>
	<table>
	<input type=submit value="Los!">

</form>

	// Nach dem Textfeld: Anlage des zugeh�rigen History-Objekts
	// und Zuordnung anf�nglicher History-Eintr�ge
<script language="javascript">

		//  History-Obj anlegen, mit ID des mit der History ausgestatteten Texteingabefelds
		// und den IDs der beiden Spans mit den Prev- und Next-Pfeilen:
	var h=new History("textH","textHPrev","textHNext");
		// und ihm die fr�heren Eingaben geben, von der �ltesten zur aktuellsten:
	h.nimm("Alpha");
	h.nimm("Beta");
	h.nimm("Gamma");
		// wenn man nichts weiter tut, ist das Eingabefeld leer, mit Pfeil-nach-oben kommt man
		// zur j�ngsten Eingabe ("Gamma")
		// Soll die sofort gezeigt werden, f�ge man ein
	h.prev();	// dazu. Zum leeren Feld kann man dann mit Pfeil-nach-unten gelangen.

</script>
</body>
</html>

*/