/*
	(c) Tillmann Wegst 2003
*/

var hideShowMousemoveZaehler=0;
var hideShowObj = new Array();

/*
	id: ID des HTML-Elements, das gezeigt und (partiell) verborgen werden soll
	richtung: in die Richtung wird beim Verbergen verschoben
	showAbstand: Abstand derjenigen Elementseite, in deren Richtung beim Verbergen verschoben wird,
		von dem Bildschirmrand, in dessen Richtung beim Verbergen verschoben wird.
		Bei Verbergen nach links: Abstand vom linken Rand, beim Verbergen nach oben: Abstand vom
		oberen Rand usw. Im Normalfall ist der Wert 0.
	rest: Ein so schmaler Rand soll sichtbar bleiben, wenn das Element "verborgen" wird
	shown: true, wenn Element initial gezeigt wird, false, wenn es verborgen wird
*/
function HideShow(id, richtung, showAbstand, rest, shown) {
	this.element=document.getElementById(id);	// das von this verwaltete HTML-Element
	this.richtung=richtung;	// in die Richtung wird zum Verbergen verschoben
		// wenn nach links oder rechts verborgen wird
	this.showAbstand=showAbstand;
	if (richtung=="left" || richtung=="right")
		this.hideAbstand=showAbstand-parseInt(this.element.style["width"])+rest;
	else
		this.hideAbstand=showAbstand-parseInt(this.element.style["height"])+rest;
	//alert("this.showAbstand=="+this.showAbstand);
	//alert("this.hideAbstand=="+this.hideAbstand);
	hideShowObj[hideShowObj.length]=this;	// this in globalem Array notieren, fortlaufend
	this.show=hsShow;
	this.hide=hsHide;
	this.shown=!shown;	// Soll-Wert umkippen, damit
	if (shown) this.show(true);	// diese Initialaktionen nicht als
	else this.hide(true);	// schon ausgef�hrt gelten
}

/*
	Methode zur schnellen bzw. gleitenden Anzeige des Elements
*/
function hsShow(schnell) {
	if (this.shown) return true;
//window.status='hsShow!';
	if (schnell)
		this.element.style[this.richtung]=this.showAbstand;
	else {
			// abs. Differenz zwischen Soll- und Ist-Abstand holen
		var diff=Math.abs(parseInt(this.element.style[this.richtung])-this.showAbstand);
		if (diff==0) { this.shown=true; return; }
		if (diff<5)	// wenn nicht mehr viel fehlt
			--diff;	// Differenz ein klein wenig ver�ndern
		else	// sonst
			diff=Math.floor(diff*0.9);	// gr��eren Schritt machen
		this.element.style[this.richtung]=""+(this.showAbstand-diff);
		if (diff>0)
			return false;
	}
	this.shown=true;	// festhalten, da� Element nun angezeigt wird
	return true;
}

/*
	Methode zum schnellen bzw. gleitenden Verbergen des Elements
*/
function hsHide(schnell) {
	//alert("this.hideAbstand=="+this.hideAbstand);
	if (!this.shown) return true;
//window.status='hsHide!';
	if (schnell)
		this.element.style[this.richtung]=this.hideAbstand;
	else {
			// abs. Differenz zwischen Soll- und Ist-Abstand holen
		//alert(this.hideAbstand);
		//alert(this.element.style[this.richtung]);
		var diff=Math.abs(parseInt(this.element.style[this.richtung])-this.hideAbstand);
		if (diff==0) { this.shown=false; return; }
		if (diff<5)	// wenn nicht mehr viel fehlt
			--diff;	// Differenz ein klein wenig ver�ndern
		else	// sonst
			diff=Math.floor(diff*0.9);	// gr��eren Schritt machen
		this.element.style[this.richtung]=""+(this.hideAbstand+diff);
		if (diff>0)
			return false;
	}
	//alert("<-- hsHide)=");
	this.shown=false;	// festhalten, da� Element nun verborgen ist
	return true;
}

function hsHideAlle(schnell) {
	//alert("hsHideAlle->, schnell=="+schnell);
	//alert("hideShowObj.length=="+hideShowObj.length);
	var done=true;
	for (i=0; i<hideShowObj.length; ++i)
		if (!hideShowObj[i].hide(schnell)) done=false;
	// alert("hsHideAlle, nach for()");
	if (!done)
		setTimeout("hsHideAlle(false)",20);
}

function hsShowEines(was,schnell) {
	if (!hideShowObj[was].show(schnell))
		setTimeout("hsShowEines('"+was+"')",20);
}

function hsMousemove(wo,schnell) {
	//alert("wo=="+wo);
	var done=true;
	if (wo=="body") {
		if (--hideShowMousemoveZaehler<=-2) {
			hsHideAlle(schnell);
			hideShowMousemoveZaehler=0;
		}
	}
	else if (++hideShowMousemoveZaehler>=2) {
		hsShowEines(wo,schnell);
		hideShowMousemoveZaehler=0;
	}
}
