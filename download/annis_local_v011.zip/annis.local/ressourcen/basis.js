/**
	(c) Tillmann Wegst 2003
*/

/** ---- HTML-Element finden -------------- */

/**
	Liefert das mit der angegebenen id versehene HTML-Element,
	soweit vorhanden.
	Wenn 'nurLokal', wird nur im aktuellen document (window.document)
	gesucht, andernfalls werden auch untergeordnete und benachbarte
	Frames, soweit vorhanden, durchsucht.
	Liefert das Element oder null.
	(tw., 28.8.2003)
*/
function gibElementMitId(id,nurLokal) {
		// zun�chst mal im aktuellen Dok suchen
	var e=document.getElementById(id);
	if (e) return e;
		// wenn nur im aktuellen document gesucht werden darf, finito
	if (nurLokal) return null;

		// also auch in Frames suchen, zun�chst in untergeordneten
	if (frames) for (var i=0; i<frames.length; ++i) {
		//alert("frames["+i+"].name=="+frames[i].name);
		if ((e=frames[i].document.getElementById(id))!=null)
			return e;
	}
		// nun auch in benachbarten
	if (parent && parent.frames) for (var i=0; i<parent.frames.length; ++i) {
		// alert("parent.frames["+i+"].name=="+parent.frames[i].name);
		if ((e=parent.frames[i].document.getElementById(id))!=null)
			return e;
	}
		// nun noch beim Parent selbst
	//if (parent && parent.document && (e=parent.document.getElementById(id))!=null) {
	//	return e;
	//}
		// nicht gefunden :-(
	return null;
}


/** ----- Style-Zuweisung ----------------------------------- */

/**
	Freie Funktion.
	'stil' h�lt einen String der Form
		"attribut:wert1:wert2...;attribut:wert1:wert2;..."
	z.B.
		"backgroundColor:#cc6699:#99dda3:#ffffff;border:2px solid:none:none"
	'id' identifiziert das HTML-Element (dem im HTML-Text also eine ID zugewiesen sein mu�).
	'n' nennt den Wert, der eingesetzt werden soll (n==1 => wert1 usw.)
	Ist 'n'<=0, wird der Stil abgeschaltet
*/
function setzeStilAnElementWertN(stil,id,n) {
	// alert("in setzeNStilAnElement...\nstil="+stil+", id="+id+", n="+n);
	var e=gibElementMitId(id);

/*
		// zun�chst mal im aktuellen Dok suchen
	var e=document.getElementById(id);
		// wenn da nicht gefunden, dann liegt es vielleicht
		// in einem untergeordneten Frame?
	if (!e && frames) for (var i=0; i<frames.length; ++i) {
		//alert("frames["+i+"].name=="+frames[i].name);
		if ((e=frames[i].document.getElementById(id))!=null)
			break;
	}
		// oder in einem benachbarten?
	if (!e && parent && parent.frames) for (var i=0; i<parent.frames.length; ++i) {
		// alert("parent.frames["+i+"].name=="+parent.frames[i].name);
		if ((e=parent.frames[i].document.getElementById(id))!=null)
			break;
	}
*/

	if (!e) { alert("Element mit ID '"+id+"' nicht gefunden"); return; }
	var stile=stil.split(";");	// Array mit je einer Stilangabe der Form "attribut:ein:aus" gewinnen
		// NB: Variable mit 'var' deklarieren, sonst bleibt Wert �ber Aufrufe hinweg stehen
		// mit w�sten Folgen: hier z.B. wird beim ersten Aufruf der Fkt. das Limit erreicht und die Schleife
		// beim zweiten Aufruf der Fkt. garnicht mehr ausgef�hrt!!! Beim Kompilieren merkt man nix!
	for (var i=0; i<stile.length; ++i) {
		var s=stile[i].split(":");	// Stil in Attributname, Wert f�r 'ein' und Wert f�r 'aus' zerlegen
		//alert("Es folgt Zuweisung: "+[s[0]]+"="+(n>0?s[n]:""));
		if (n<s.length)
			e.style[s[0]]=n>0?s[n]:"";	// und jetzt den Stil einsetzen
		else
			alert("fehlendes Stilattribut "+n+" in "+stile[i]+"!");
	}
}


/**
	Freie Funktion.
	'stil' h�lt einen String der Form
		"attribut:wert;attribut:wert;..."
	z.B.
		"backgroundColor:#cc6699:#ffffff;border:2px solid:none"
	'id' identifiziert das HTML-Element (dem im HTML-Text also eine ID zugewiesen sein mu�).
	Der jeweilige Wert wird eingesetzt, wenn 'ja' true; andernfalls wird das Attribut abgeschaltet.
*/
function setzeStilAnElement(stil,id,ja) {
	setzeStilAnElementWertN(stil,id,ja?1:0)
}


/**
	Hier wird ein Array mit IDs von Elementen �bergeben, denen
	der angegebene Stil zugewiesen werden soll. (s. vorige Fkt.)
*/
function setzeStilAnElemente(stil,ids,ja) {
	for (var i=0; i<ids.length; ++i)
		setzeStilAnElement(stil,ids[i],ja);
}



/** ------- display-(Um)Schaltung -------------- */

var displayElements = new Array();


/**
	Setzt das HTML-Element mit der angegebenen 'id'
	per Stil-Attribut 'display' auf den Wert 'wert'.
	Fehlt die Angabe von 'wert', wird "inline" verwendet.
	Andere m�gliche Werte sind "block" und "list-item".
	("list-item" bewirkt unter IE 6.0 nichts.)
		NB: Die Fkt. bewirkt nur dann etwas, wenn das
	Element nicht mit displayUm() auf sichtbar fixiert
	wurde! (Restriktion k�nnte aufgehoben werden,
	dann lie�e sich die display-Art auch direkt wechseln
	(von "inline" zu "block").
*/
function displayAn(id,wert) {
	var e=displayElements[id];	// schauen, ob Element als fixiert angezeigt notiert ist
	if (!e) // nur, wenn dem nicht so ist:
		setzeStilAnElement("display:"+(wert?wert:"inline"),id,1);
}

/**
	Setzt das HTML-Element mit der angegebenen 'id'
	per Stil-Attribut 'display' auf den Wert 'none', d.h.
	macht es unsichtbar.
		NB: Die Fkt. bewirkt nur dann etwas, wenn das
	Element nicht mit displayUm() auf sichtbar fixiert
	wurde!
*/
function displayAus(id) {
	var e=displayElements[id];	// schauen, ob Element als fixiert angezeigt notiert ist
	if (!e)	// nur, wenn dem nicht so ist:
		setzeStilAnElement("display:none",id,1);
}


/**
	Liefert ein Image-Obj und ordnet dessen src-Attribut
	den angegebenen Wert (URL einer Bilddatei) zu
*/
function erzeugeImage(src) {
	var img = new Image();
	img.src=src;
	return img;
}

/**
	class f�r Obj, die zwei Bilder verwalten, zwischen denen man umschalten kann.
*/
function Schalter(imgName, einschaltBild, ausschaltBild, tip, textEin, textAus) {
	this.imgName=imgName;	// Name des 'name'-Attributs des <img>-Elements, dem abwechselnd das eine und das andere Bild bekommt
	this.einSchalter=erzeugeImage(einschaltBild);	// das Bild, das im Fall von schalteAuf(true) gezeigt werden soll
	this.ausSchalter=erzeugeImage(ausschaltBild); // das Bild, das im Fall von schalteAuf(false) gezeigt werden soll
	this.tip=tip;	// wenn true, wird per 'title'-Attribut ein 'Einblenden'/'Ausblenden'-Tooltip gezeigt
	this.textEin=textEin?textEin:'Einblenden';
	this.textAus=textAus?textAus:'Ausblenden';
	this.schalteAuf=new Function(
		"ein",
		"document.images[this.imgName].src= ein ? this.einSchalter.src : this.ausSchalter.src;  if (this.tip) document.images[this.imgName].title=(ein?this.textEin:this.textAus);"
	);
}

	// globaler Array f�r alle Schalterelemente
var schalter = new Array();

	// BEISPIEL:
	// einen Schalter anlegen, mit dem das Element "zone" sichtbar unsichtbar geschaltet werden soll,
	// und ihm mitteilen wie der 'name' des Schalter-<img>-ELements lautet und zwischen welchen beiden Bilddateien
	// umgeschaltet werden soll.
	// schalter["zone"] = new Schalter("zoneSchalter", "display-plus.gif","display-minus.gif");


/**
	Schaltet das HTML-Element mit der angegebenen 'id'
	per Stil-Attribut 'display' um:
	Ist es gerade ausgeschaltet, wird es eingeschaltet, und
	umgekehrt.
	Fehlt die Angabe von 'wert', wird "inline" verwendet.
	Andere m�gliche Werte sind "block" und "list-item".
	("list-item" bewirkt unter IE 6.0 nichts.)
*/
function displayUm(id,wert) {
	var e=displayElements[id];	// schauen, ob Element als fixiert angezeigt notiert ist
	if (e) {
		// window.status="e!=null!";
		wert="none";
		displayElements[id]=null;
	}
	else {
		// window.status="e==null!";
		if (!wert) wert="inline";
		displayElements[id]=id;
	}
		// falls es ein Schalter-Obj gibt, mit dem Element id sichtbar/unsichtbar geschaltet
		// wird, dem den neuen Zustand mitteilen, damit er das Schalterbild wechseln kann.
	//window.status="vor Check auf schalter[id], wert=="+wert+", id=="+id;
	if (schalter[id]) {
		//window.status="yep!";
			// wenn id jetzt unsichtbar geschaltet wird, soll das Bild zum Einschalten gezeigt werden
		schalter[id].schalteAuf(wert=="none");
	}

		// und jetzt das Element selber (un)sichtbar schalten
	setzeStilAnElement("display:"+wert,id,1);

		// den Anzeigezustand an das Zustandsobj. melden, dessen
		// Inhalt an den Server geschickt werden soll (10.9.2003)
	nimmZFS(id,wert);
}



/** ------------ ClipScrolling-Fkt. --------------------- */

var clipscrollfenster = new Array();	// macht alle Instanzen von ScrollFenster �ber ihren Namen zug�nglich

/*
	class ClipScrollFenster
	mit ID des HTML-Elements, dessen Inhalt verschoben werden soll
	und den Anfangswerten f�r das clip-rect, das den Ausschnitt bestimmt
*/
function ClipScrollFenster(id,oben,rechts,unten,links) {
		// Element, auf dem der Ausschnitt bewegt wird
	this.id=id;
	this.basis=document.getElementById(id);

		// Dimensionen des Elements, von dem zu jeder Zeit nur ein Ausschnitt gezeigt wird
	this.breite=parseInt(this.basis.style.width);		// Breite und
	this.hoehe=parseInt(this.basis.style.height);	// H�he

	// alert("width=="+this.element.style.width);
		// Anf�ngliche Lage des clip-Rechtecks auf der Basis
	this.coben=oben;		// Abstand des oberen Clip-Rands vom oberen Rand der Basis
	this.crechts=rechts;// Abstand des rechten Clip-Rands vom linken(!)  Rand der Basis
	this.cunten=unten;	// Abstand des unteren Clip-Rands vom oberen(!) Rand der Basis
	this.clinks=links;			// Abstand des linken Clip-Rands vom linken  Rand der Basis

		// f�r automatisches Scrollen
	this.auto=false;
	// this.faktor=1;	// multipliziert weite beim automatischen Scrollen; noch nicht aktiv

	// alert(this.element);
	this.scroll=scroll;
	this.setzeClipRect=new Function("","this.basis.style.clip='rect('+this.coben+' '+this.crechts+' '+this.cunten+' '+this.clinks+')';");
	this.setzeClipRect();
	this.zumRand=zumRand;	// versetzt clip an eine der Seiten der Basis

		// und die Instanz im globalen Array festhalten
	clipscrollfenster[id]=this;
}

/*
	Methode von ClipScrollFenster
	richtung: horizontal oder vertikal
	weite: Zahl > 0: nach rechts; Zahl < 0: nach links
	auto: immer weiter scrollen?
*/
function scroll(richtung,weite,auto) {
	//alert("in scrolle(), richtung=="+richtung+", weite=="+weite);
	// window.status="weite=="+weite;

	if (richtung=="horizontal") {
		// window.status=""+this.breite;
			// Verschiebung begrenzen
		if (this.clinks+weite < 0) {
			weite=-this.clinks;
			auto=false;
		}
		else if (this.crechts+weite > this.breite) {
			weite=this.breite-this.crechts;
			auto=false;
		}
			// Verschiebung zuweisen
		this.clinks+=weite;
		this.crechts+=weite;
			// und die Basis gegenl�ufig bewegen, damit der Ausschnitt
			// auf dem Bildschirm fixiert bleibt
		var li=parseInt(this.basis.style.left);
		this.basis.style.left=(li-weite)+"px";
	}
	else if (richtung=="vertikal") {
			// Verschiebung begrenzen
		if (this.coben+weite < 0) {
			weite=-this.coben;
			auto=false;
		}
		else if (this.cunten+weite > this.hoehe) {
			weite=this.hoehe-this.cunten;
			auto=false;
		}
			// Verschiebung zuweisen
		this.coben+=weite;
		this.cunten+=weite;
			// und die Basis gegenl�ufig bewegen, damit der Ausschnitt
			// auf dem Bildschirm fixiert bleibt
		var ob=parseInt(this.basis.style.top);
		this.basis.style.top=(ob-weite)+"px";
	}

		// nun den Ausschnitt neu setzen
	this.setzeClipRect();

	if (auto) {
		this.richtung=richtung;
		this.weite=weite;
		this.auto=auto;	// auto gibt den Timout-Wert an, d.h. die Zeit in Millisekunden,
						// nach der ein weiterer Aufruf erfolgen soll

		// das tut!:
		setTimeout("cAutoScroll('"+this.id+"')",auto);
		// da l�uft irgendwas aus dem Ruder:
		// setTimeout("cScroll('"+this.id+"', '"+richtung+ "','"+weite+"','"+"true"+"')",50);
	}
}

/**
	Methode von ClipScrollFenster,
	verschiebt den gezeigten Ausschnitt an einen
	der R�nder der Basis
*/
function zumRand(der) {
	var left=parseInt(this.basis.style.left);
	var top=parseInt(this.basis.style.top);
	if (der=="links") {
		var cb=this.crechts-this.clinks;	// clip-Breite
		// window.status="this.clinks="+this.clinks+", altleft="+this.basis.style.left;
		this.basis.style.left=(this.clinks+left)+"px";
		// window.status="neuleft="+this.basis.style.left;
		this.clinks=0;
		this.crechts=cb;
	}
	else if (der=="rechts") {
		var cb=this.crechts-this.clinks;
		//window.status="left="+left+", cb=="+cb+", this.breite=="+this.breite;
		this.basis.style.left=(left-(this.breite-cb-this.clinks))+"px";
		this.crechts=this.breite;
		this.clinks=this.breite-cb;
		//this.basis.style.left=""+cb-this.breite+"px";
	}
	else if (der=="oben") {
		var ch=this.cunten-this.coben;
		this.basis.style.top=(this.coben+top)+"px";
		this.coben=0;
		this.cunten=ch;
	}
	else if (der=="unten") {
		var ch=this.cunten-this.coben;
		this.basis.style.top=(top-(this.hoehe-ch-this.coben))+"px";
		this.cunten=this.hoehe;
		this.coben=this.hoehe-ch;
	}
	this.setzeClipRect();
}

/*
	F�r einen Scroll-Aufruf des ClipScrollFensters mit dieser ID
	via setTimeout().
	Richtung und Weite sind im CSF selber festgehalten.
*/
function cAutoScroll(id) {
	// window.status="in autoScroll(), id=="+id;
	var f=clipscrollfenster[id];
	if (f.auto)	// falls nicht (inzwischen) abgeschaltet
		f.scroll(f.richtung,f.weite,f.auto);
}

/*
	Schaltet Dauerscrollen im ClipScrollFenster mit dieser ID ab
*/
function cAutoScrollOff(id) {
	var f=clipscrollfenster[id];
	f.auto=false;
}

/*
	Ver�ndert die Scrollweite um den angegebenen 'faktor'
*/
function cTempo(id, faktor) {
	var f=clipscrollfenster[id];
//	f.auto/=faktor;	// ja, das ist richtig. Doppelt so schnell -> halbe Timeout-Zeit
	f.weite*=faktor;	// ja, das ist richtig. Doppelt so schnell -> halbe Timeout-Zeit
	if (f.auto<1) f.auto=1;
}

/*
	Aktiviert Scrolling (ggf. Dauermodus) f�r das ClipScrollFenster
	mit dieser (HTML-Element-)ID.
	'richtung' ist "horizontal" oder "vertikal"
	'weite' die Verschiebungsweite in Pixel
*/
function cScroll(id,richtung,weite,auto) {
	var f=clipscrollfenster[id];
	// window.status="id="+id+", richtung="+richtung+", weite="+weite+",auto="+auto+",f="+f;
	f.scroll(richtung,weite,auto);
}

/*
	Aktiviert horizontales Scrolling (ggf. Dauermodus)
	f�r das ClipScrollFenster 	mit dieser (HTML-Element-)ID.
	'weite' die Verschiebungsweite in Pixel
*/
function cHScroll(id,weite,auto) {
	cScroll(id,"horizontal",weite,auto);
}

/*
	Aktiviert vertikales Scrolling (ggf. Dauermodus)
	f�r das ClipScrollFenster 	mit dieser (HTML-Element-)ID.
	'weite' die Verschiebungsweite in Pixel
*/
function cVScroll(id,weite,auto) {
	cScroll(id,"vertikal",weite,auto);
}

/*
	Verschiebt den Ausschnitt des per 'id' identifizierten
	ClipScrollFensters an den angegebenen Rand
	("links","rechts","oben" oder "unten")
*/
function cRand(id,der) {
	var f=clipscrollfenster[id];
	f.zumRand(der);
}

/*
	Notiert die letzte MausPos;
	(wird nur f�r Netscape benutzt)
*/
function notiereMausPos(event) {
	mausX=event.pageX;
	mausY=event.pageY;
	// window.status="x=="+mausX+", y=="+mausY;
}

var netscape = (navigator.appName == "Netscape");
var mausX;	// h�lt die letzte Mauspos. fest, relativ zur HTML-Seite, in x-
var mausY;	// bzw. y-Position
if (netscape) {
	onmousemove=notiereMausPos;
	onmousedown=notiereMausPos;
	onclick=notiereMausPos;
}

/* ---------- ToolTip-Fkt. ---------------------- */
/**
	Schaltet ein absolut positionierbares Element mit einem erl�uternden
	Text sichtbar bzw. unsichbar.
	Der Text wird im Parameter �bermittelt. Gibt es einen, wird sichtbar
	geschaltet, andernfalls unsichtbar.
	Das Element wird an der aktuellen Event-Position angezeigt.

	Damit das ganze funktioniert, setze man irgendwo in den <body>
	das
		<div id=tip style="position:absolute; display:none; background-color:#ffff99; padding:2"></div>
	(oder so �hnlich, den Stil kann man �ndern und nat�rlich auch im
	<style>-Element definieren, wichtig sind absolute Positionierung und
	anf�ngliche Unsichtbarkeit)

	Zur Nutzung ruft man die Fkt. tip() al gusto auf,
		mit Text zur Anzeige,
		ohne Text zum Abschalten,
	z.B.:
	<span onMouseover='tip("Hier spricht das Zeb")' onMouseout='tip()'>Zebra</span> und
	<span onMouseover='tip("Und hier\nist der\nGiraff!")' onMouseout='tip()'>Giraffe</span>

	tw., 27.8.2003
*/
function tip(text) {
	var tip=document.getElementById("tip");
	if (text) {	// wenn Text angegeben
		//tip.innerText=text;	// tut mit IE 6, nicht mit NS 7.1
		//tip.firstChild.nodeValue=text;	// das kann (nur?) NS 7.1
		tip.innerHTML=text;	// das k�nnen IE 6 und NS 7.1; text darf HTML-Tags enthalten, <br> etc.!
		var x=netscape ? mausX : window.event.clientX;
		var y=netscape ? mausY : window.event.clientY;
			// Tipfenster etwas nach
		x+=9;	// rechts und
		y-=6;	// oben versetzen
		tip.style["left"]=x+"px";	// damit das Fensterchen
		tip.style["top"]=y+"px";	// plazieren
		tip.style["display"]="block";	// und jetzt sichtbar machen
	}
	else // andernfalls
		tip.style.display="none";	// unsichtbar schalten
}


/* --- Halten von Zust�nden in einer Seite und zur �bergabe an den Server ------- */

/**
	Sammelt Attribut-Wert-Paare auf, wobei jedes Attribut nur 1x mit 1 Wert vorkommt,
	d.h. wird ein Attribut erneut �bergeben, wird sein bisheriger Wert �berschrieben
	10.9.2003
*/
function Zustand() {
	this.attrs = new Array();	// notiert die Namen der vorkommenden Attribut
	this.werte = new Array();	// assoziiert Attr-Namen mit Attr-Werte
		// Methode zum Festhalten eines Attr-Wert-Paars. Wenn 'wert' fehlt, wird "ja" eingesetzt
	//this.nimm = new Function("attr,wert","if (!wert) wert='ja'; if (!this.werte[attr]) this.attrs[this.attrs.length]=attr; this.werte[attr]=wert; window.status=this.gibAlle();");
	this.nimm = new Function("attr,wert","if (!wert) wert='ja'; if (!this.werte[attr]) this.attrs[this.attrs.length]=attr; this.werte[attr]=wert;");
		// Methode zum Abfragen eines Attribut-Werts
	this.gib = new Function("attr","return this.werte[attr];");
		// Liefert alle Attribut-Wert-Paare zum Anh�ngen an eine URL
	this.gibAlle = new Function("","var ret=''; for (var i=0; i<this.attrs.length; ++i) { if (i>0) ret+='&'; ret+=this.attrs[i]+'='+this.werte[this.attrs[i]];	}	return ret;");
}

	// ein Obj, das Zust�nde sammelt, die an den Server �bermittelt werden sollen
var zustandFuerServer= new Zustand();

	// Zustand (Attribut und Wert) festhalten, der beim n�chsten Aufruf an Server
	// �bermittelt werden soll. 'wert' darf null sein, es wird dann "ja" eingetragen
function nimmZFS(attr,wert) {
	// alert("attr=="+attr+", wert=="+wert);
	zustandFuerServer.nimm(attr,wert);
}

	// F�hrt einen Link auf die angegebene URL aus und �bergibt als Parameter
	// etwaige in 'zustandFuerServer' eingetragene Attribut-Wert-Paare
function oeffneSeite(url) {
	var zp=zustandFuerServer.gibAlle();	// liefert sowas wie "Heinz=dick&Lisa=lieb"
	if (zp) {	// wenn es etwas anzuf�gen gibt
		url += (url.indexOf('?')>=0) ? "&" : "?";	// je nachdem ein "?" oder "&" anf�gen
		url+=zp;	// und die Liste mit Attribut-Wert-Paaren
	}
	window.location=url;	// und dann ernst machen

}

	// Macht das Element mit der angegebenen ID nach
	// der angegebenen Zahl Millisekunden unsichtbar
function verzoegertAusblenden(id,ms) {
  //mg: michael: auskommentiert --- kein ausblenden erwuenscht.
  //	setTimeout("setzeStilAnElement('display:none','"+id+"',true)",ms);
}
