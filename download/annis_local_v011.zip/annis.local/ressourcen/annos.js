/*
	(c) Tillmann Wegst 2003
*/

	// Globales
var annoTypen = new Array();	// Liste der AnnoTypen
var annos = new Array();	// Liste der Annos
var schaltFlaechen = new Array();	// nimmt s�mtliche AnnoTypen und Annos auf

/*
	class AnnoTypenSatz, ctor

	H�lt einen Menge von AnnotationsTypen
*/
function AnnoTypenSatz (name, annotypen) {
	this.name_=name;	// Name des Typensatzes, z.B. "Syntax" oder "RST"
	this.annotypen_=annotypen;	// Elemente der Typenmenge, etwa "NP","Det","Adj", (evtl. Array von 'AnnotationsTyp'-Objekten)
}

/*
	class AnnoTyp, ctor

	H�lt einen AnnotationsTyp, z.B. "NP".
*/
function AnnoTyp(name, stil, schalter) {
	this.name_=name;	// z.B. "NP"
	this.annos_=new Array();	// Array von vorkommenden Annotationen (Anno-Obj.) dieses Typs
	this.stil_=stil;			// String mit Stilangabe/n (fast a la CSS, aber nicht ganz)
	this.schalter_=schalter;	// Id des HTML-Elements, mit dem die Hervorhebung des Typs geschaltet wird
	this.aktiv_=true;	// Hervorhebungen geschaltet, MouseOver wirksam?

		// Methoden
	this.nimmAnno = new Function("anno,id","this.annos_[this.annos_.length]=anno;");
	this.hervorhebeSelbst = new Function("an",
		"setzeStilAnElement(this.stil_,this.schalter_,an); "+
		"for (var i=0; i<this.annos_.length; ++i) "+
		"	this.annos_[i].hervorhebeSelbst(an); "
	);
	this.hervorhebeSpannen = new Function("an",
		"for (var i=0; i<this.annos_.length; ++i) "+
		"	this.annos_[i].hervorhebeSpannen(an);"
	);
	this.umschalteAktiv = new Function("","this.aktiv_=!this.aktiv_;	for (var i=0; i<this.annos_.length; ++i)	this.annos_[i].aktiv_=this.aktiv_;");
	this.mouse=mouse;

		// und
	annoTypen[this.name_]=this;	// Typ in die globale Liste aufnehmen
	schaltFlaechen[schaltFlaechen.length]=this;
}


/*
	class Anno, ctor

	H�lt eine einzelne Annotation.
	spannen: Die Spannen Text, die zu der Anno geh�ren. Array mit HTLM-IDs.
	balken:  die Balken-Elemente, mit denen die Spannen markiert werden. Array mit HTML-IDs
*/
function Anno (id, typ, spannen, balken) {
	this.spannen_=spannen;	// die zugeh�rigen Textspannen-HTML-Elemente
	this.balken_=balken;		// die m�glichen zugeh�rigen Balken f�r die Hervorhebung
	this.stil_=annoTypen[typ].stil_;	// den Stil des Typs auch hier festhalten
	this.aktiv_=true;
		// Methoden
	this.hervorhebeSelbst = new Function("an",
		"setzeStilAnElemente(this.stil_,this.balken_,an);"
	);
	this.hervorhebeSpannen = new Function("an",
		"setzeStilAnElemente(this.stil_,this.spannen_,an);"
	);
	this.umschalteAktiv = new Function("","this.aktiv_=!this.aktiv_");
	this.mouse=mouse;
		// und this eintragen
	annos[id]=this;	// in Array von Annos
	annoTypen[typ].nimmAnno(this,id);	// die Anno an das zugeh�rige AnnotationsTyp-Obj melden
	schaltFlaechen[schaltFlaechen.length]=this;
}

/**
	Methode von sowohl Anno als auch AnnoTyp!
*/
function mouse(wie) {
	if (wie=="over") {
		if (this.aktiv_) this.hervorhebeSpannen(true);
	}
	else if (wie=="out") {
		if (this.aktiv_) this.hervorhebeSpannen(false);
	}
	else if (wie=="click") {
		this.umschalteAktiv();
		this.hervorhebeSelbst(this.aktiv_);
		this.hervorhebeSpannen(this.aktiv_);
	}
}

/**
	Handler f�r onMouseover, onMouseout und onClick bei AnnoTypSchalter
	annoTypMouse()
*/
function aTM(typ,wie) {
	annoTypen[typ].mouse(wie);
}


/**
	Handler f�r onMouseover, onMouseout und onClick bei AnnoSchalter (Balken)
	annoMouse()
*/
function aM(anno,wie) {
	// alert("in annoMouse(), anno=="+anno);
	annos[anno].mouse(wie);
}

/**
	Wird nach Laden der Seite aufgerufen, um den
	AnnoTyp-Schaltern sowie den AnnoBalken ihre anf�nglichen
	Stilattribute zu geben. Die Zuweisung selber h�ngt vom
	Zustand des aktiv_-Flags ab, und das ist initial eben auf true
	gesetzt.
*/
function initHervorhebung() {
	for (var i=0; i<schaltFlaechen.length; ++i)
		schaltFlaechen[i].hervorhebeSelbst(true);
}

var framesGeladen=0;

/**
	Wird von Frames aufgerufen, wenn ihre src-Seite geladen wurde.
	Sind s�mtliche Seiten da, wird ein Hervorhebungsdurchgang gemacht
*/
function frameGeladen() {
	if (++framesGeladen>=frames.length)	// wenn beide untergeordneten Frames geladen,
		initHervorhebung();	// die Hervorhebung veranlassen
}
