Corpus Name:	Aeschylus.Persae.L1-18
Base text: 	Aeschylus, Persae � lines 1-18
Texts/Tokens: 	1 / 87	
Language:	Classical Greek (Polytonic)	
Annotations:	POS, lemma, grammatical function, labeled syntax trees	
Source: 	Courtesy of Francesco Mambrini / Perseus Project, Tufts University
